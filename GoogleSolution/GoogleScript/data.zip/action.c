Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=121", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://www.gstatic.com/og/_/ss/k=og.qtm.8RUPaHb7e5o.L.W.O/m=qcwid/excm=qaaw,qadd,qaid,qein,qhaw,qhba,qhbr,qhch,qhga,qhid,qhin/d=1/ed=1/ct=zgms/rs=AA2YrTungzasoekTaLKrPFUaQFpakqDmnA", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://www.gstatic.com/og/_/js/k=og.qtm.en_US.ZEEp2pdSHOQ.2019.O/rt=j/m=qabr,q_d,qcwid,qapid,qald,q_dg/exm=qaaw,qadd,qaid,qein,qhaw,qhba,qhbr,qhch,qhga,qhid,qhin/d=1/ed=1/rs=AA2YrTvRRKYp7I5vTn-AtFvme6Qlo6hq9Q", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://content-autofill.googleapis.com/v1/pages/ChVDaHJvbWUvMTIxLjAuNjE2Ny4xNDASGQn11VQ7sgCk8RIFDWlIR0chrbMLunyG1js=?alt=proto", "Referer=", ENDITEM, 
		LAST);

	web_add_cookie("1P_JAR=2024-02-05-10; DOMAIN=ogs.google.com");

	web_add_cookie("AEC=Ae3NU9PygQlPD4V4dzuGnb6wpu43KGwrBUWMVL5g9r3bSGVAN92z5YTW1Q; DOMAIN=ogs.google.com");

	web_add_cookie("NID=511=CqZBrgjnIt9qIB2Yuu9ioA5w3XJfXAfAhPNJ_HdPZ6a1w0tWiH5Ak4Bxc3xKcXXy86UGcXyhajYZdlCnaki1ptvzrKA_F-WWNMN9MOMC3BTNe4J7Id7tmKivFlF2yjXk0lqGhYjqYqB4PlZvX0EEY648-G2yb46hoEfx5ANJGBad4LX4qQNgJWr-; DOMAIN=ogs.google.com");

	web_add_cookie("1P_JAR=2024-02-05-10; DOMAIN=apis.google.com");

	web_add_cookie("AEC=Ae3NU9PygQlPD4V4dzuGnb6wpu43KGwrBUWMVL5g9r3bSGVAN92z5YTW1Q; DOMAIN=apis.google.com");

	web_add_cookie("NID=511=CqZBrgjnIt9qIB2Yuu9ioA5w3XJfXAfAhPNJ_HdPZ6a1w0tWiH5Ak4Bxc3xKcXXy86UGcXyhajYZdlCnaki1ptvzrKA_F-WWNMN9MOMC3BTNe4J7Id7tmKivFlF2yjXk0lqGhYjqYqB4PlZvX0EEY648-G2yb46hoEfx5ANJGBad4LX4qQNgJWr-; DOMAIN=apis.google.com");

	web_url("callout", 
		"URL=https://ogs.google.com/widget/callout?prid=19037050&pgid=19037049&puid=a5627eb5c02923db&cce=1&dc=1&origin=https%3A%2F%2Fwww.google.com&cn=callout&pid=1&spid=538&hl=en", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.google.com/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://apis.google.com/_/scs/abc-static/_/js/k=gapi.gapi.en.GsbA68hXs80.O/m=gapi_iframes,googleapis_client/rt=j/sv=1/d=1/ed=1/rs=AHpOoo899t-H8Lxb3OqzMDuPn6TV_i36ag/cb=gapi.loaded_0", "Referer=https://www.google.com/", ENDITEM, 
		LAST);

	web_add_cookie("1P_JAR=2024-02-05-10; DOMAIN=play.google.com");

	web_add_cookie("AEC=Ae3NU9PygQlPD4V4dzuGnb6wpu43KGwrBUWMVL5g9r3bSGVAN92z5YTW1Q; DOMAIN=play.google.com");

	web_add_cookie("NID=511=CqZBrgjnIt9qIB2Yuu9ioA5w3XJfXAfAhPNJ_HdPZ6a1w0tWiH5Ak4Bxc3xKcXXy86UGcXyhajYZdlCnaki1ptvzrKA_F-WWNMN9MOMC3BTNe4J7Id7tmKivFlF2yjXk0lqGhYjqYqB4PlZvX0EEY648-G2yb46hoEfx5ANJGBad4LX4qQNgJWr-; DOMAIN=play.google.com");

	web_custom_request("log", 
		"URL=https://play.google.com/log?format=json&hasfast=true", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://www.google.com/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded;charset=UTF-8", 
		"Body=[[1,null,null,null,null,null,null,null,null,null,[null,null,null,null,\"en-IN\",null,null,null,[[[\"Not A(Brand\",\"99\"],[\"Google Chrome\",\"121\"],[\"Chromium\",\"121\"]],0,\"Windows\",\"10.0.0\",\"x86\",\"\",\"121.0.6167.140\"],[1,0,0,0,0]]],373,[[\"1707126607004\",null,null,null,null,null,null,\"[108,40400,538,1,\\\"602241693.0\\\",\\\"yrHAZfDCGLKmg8UPjr6MaA\\\",null,null,null,\\\"en\\\",\\\"IND\\\",0,8,2194,null,0,0,null,\\\"og-80718f9e-a408-45b5-98e7-2573bf54315c\\\",null,null,null,"
		"null,null,null,null,0,null,null,null,19037050,null,null,null,null,0,[1],1,null,null,null,null,null,null,null,null,null,null,null,[0,2],null,null,null,null,0,null,[2,5,\\\"sl\\\",41],null,null,0,0,1]\",null,null,null,null,null,null,-19800,[null,null,null,\"[null,null,[3700949]]\"],null,null,null,null,1],[\"1707126607010\",null,null,null,null,null,null,\"[107,40400,538,1,\\\"602241693.0\\\",\\\"yrHAZfDCGLKmg8UPjr6MaA\\\",null,null,null,\\\"en\\\",\\\"IND\\\",0,8,2200,null,0,0,null,\\\""
		"og-80718f9e-a408-45b5-98e7-2573bf54315c\\\",null,null,null,null,null,null,null,8,null,null,null,19037050,null,null,null,null,0,[2],2,null,null,null,null,null,null,null,null,null,null,null,[0,2],null,null,null,null,0,null,[2,5,\\\"sl\\\",41],null,null,0,0,1]\",null,null,null,null,null,null,-19800,[null,null,null,\"[null,null,[3700949]]\"],null,null,null,null,2]],\"1707126608012\",null,null,null,null,null,null,null,null,null,null,null,null,null,[[null,[null,null,null,null,null,null,null,null,null,"
		"null,null,null,122505695]],9]]", 
		EXTRARES, 
		"Url=https://fonts.gstatic.com/s/roboto/v18/KFOmCnqEu92Fr1Mu4mxK.woff2", "Referer=https://ogs.google.com/", ENDITEM, 
		"Url=https://fonts.gstatic.com/s/googlesans/v58/4Ua_rENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RFD48TE63OOYKtrw2IJllpyk.woff2", "Referer=https://ogs.google.com/", ENDITEM, 
		LAST);

	lr_think_time(57);

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=13:NAyUfqg1iAcb-34Nqg8thn2tceuysLE1Vpggi_5T2wM&cup2hreq=512e7691bffe8591fe50333c8d42077df1bc0baac9a8b3d3f3bfd677ea1d917e", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.30f5f886b824ca1efde5174370fc03cab3c02e9c309bc381857430f5843a510b\"}]},\"ping\":{\"ping_freshness\":\"{155ddcb1-67c9-4b50-9516-c22fd60844d5}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"1.3.36.311\"},{\"appid\":\""
		"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"GGLS\",\"cohort\":\"1:1zdx:\",\"cohortname\":\"Chrome 106+\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{eacbd05e-ea8f-4e12-a56e-62374dbc9fb1}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"4.10.2710.0\"},{\"accept_locale\":\"ENGB500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"GGLS\",\"cohort\":\"1:s6f/20ol:20or@0.5\",\"cohortname\":\"Rollout\",\"enabled\":true,\"installdate\":5887,\""
		"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.8069f8805123f74944304604381770bb694317c9e1044e096f540222dc56c0f6\"}]},\"ping\":{\"ping_freshness\":\"{5487b642-0bd6-4fc1-ab67-80b363922188}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"20230923.567854667.14\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"GGLS\",\"cohort\":\"1:bm1:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\""
		"1.cd1978742a4afdbaaa15bf712d5c90bef4144caa99024df98f6a9ad58043ae85\"}]},\"ping\":{\"ping_freshness\":\"{ba3951c3-1ae3-4737-a615-231c3b0924d9}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"9.49.1\"},{\"appid\":\"neifaoindggfcjicffkgpmnlppeffabd\",\"brand\":\"GGLS\",\"cohort\":\"1:1299:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.c900ba9a2d8318263fd43782ee6fd5fb50bad78bf0eb2c972b5922c458af45ed\"}]},\"ping\":{\""
		"ping_freshness\":\"{5b04315e-4d85-43e4-9eca-d6c1f29ddf9c}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"1.0.2738.0\"},{\"appid\":\"kiabhabjdbkjdpjbpigfodbdjmbglcoo\",\"brand\":\"GGLS\",\"cohort\":\"1:v3l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6134,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.4a6508925b2ffec931c1e3931ddeb15ca41d820a8264cd5a962b526e9932bcdf\"}]},\"ping\":{\"ping_freshness\":\"{878b71dc-c82b-4eb4-8f93-e0232c66af8d}\",\"rd\":6243},\"updatecheck\":{}"
		",\"version\":\"2024.1.2.1\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"GGLS\",\"cohort\":\"1:j5l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.fd515ec0dc30d25a09641b8b83729234bc50f4511e35ce17d24fd996252eaace\"}]},\"ping\":{\"ping_freshness\":\"{45a08c1f-a340-461b-bb09-87ae8d76ebc4}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"GGLS\",\""
		"cohort\":\"1:cux:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.f4f1eb04881095d1cc8f2e1799a8144c10476dc1088a03ecdb4418644040a554\"}]},\"ping\":{\"ping_freshness\":\"{1d8e6ca6-2e7e-429d-a045-23fd206116c5}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"63\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\""
		":[{\"fp\":\"1.3a118962ef814c91f6476bb9f0de58afa63103af6ac1b8729be9b39a86789e96\"}]},\"ping\":{\"ping_freshness\":\"{6ab7c500-7bcd-4024-a902-062b4afd2c18}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"1.0.0.15\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\":\"GGLS\",\"cohort\":\"1:10zr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{a31ffb2b-f548-4652-96dd-560e170e9916}\",\"rd\":6243},\"updatecheck\":{},\"version\":"
		"\"1.0.7.1652906823\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"GGLS\",\"cohort\":\"1:ofl:\",\"cohortname\":\"stable64\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{0dc416dc-436c-4de8-b4ee-27a2bd726364}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"GGLS"
		"\",\"cohort\":\"1:s7x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.887c873b6c3a26844482754c8534268fcd848b8c543b652626b4d4ec367f26fd\"}]},\"ping\":{\"ping_freshness\":\"{a403ccef-436b-45ae-8960-3f2f186a459b}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"3017\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"GGLS\",\"cohort\":\"1:wvr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":"
		"\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.c52c62a7c50daf7d3f73ec16977cd4b0ea401710807d5dbe3850941dd1b73a70\"}]},\"ping\":{\"ping_freshness\":\"{5701be3e-02a0-4254-a984-d47853c9a974}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"120.0.6050.0\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"GGLS\",\"cohort\":\"1:w0x:\",\"cohortname\":\"All users\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\""
		"1.545666a4efd056351597bb386aea1368105ededc976ed5650d8682daab9f37ff\"}]},\"ping\":{\"ping_freshness\":\"{17d2eff8-7ece-4282-a753-d98e01a7b307}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"3\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\",\"brand\":\"GGLS\",\"cohort\":\"1:18ql:\",\"cohortname\":\"Auto Stage3\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.e4bdca96fb46d22bc12f5bc5bdb5cdb518555fd1762653f8afc96d06b34ec74b\"}]},\"ping\":{\""
		"ping_freshness\":\"{03b894d2-b297-45bc-b886-f999b917e635}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"852\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"GGLS\",\"cohort\":\"1:ut9/1a0f:23ml@0.1\",\"cohortname\":\"M108 and Above\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.c45cd56a0a8da0883c8f9757b31891d6c628f38cb80724015ffdf33b419a73f3\"}]},\"ping\":{\"ping_freshness\":\"{52cfc89c-4b3c-45e2-8bc3-f8d2c0c87a2f}\",\"rd\":6243},\""
		"updatecheck\":{},\"version\":\"2023.11.27.1202\"},{\"appid\":\"jflhchccmppkfebkiaminageehmchikm\",\"brand\":\"GGLS\",\"cohort\":\"1:26yf:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6148,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.1ef9f0df4172bd73d0dd61c5b9f31c13df8522d4581a638a37be32dad0d920c4\"}]},\"ping\":{\"ping_freshness\":\"{e10ea4bb-070c-4d68-9d99-37cc91c0e9e7}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"2024.2.3.1\"},{\"appid\":\""
		"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"GGLS\",\"cohort\":\"1:lwl:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.cadbf9a5f27721576d77d35576f37ca01ac34d86bce73958bf71cde62af71b48\"}]},\"ping\":{\"ping_freshness\":\"{8a29a884-5d57-4274-9909-e3a4e8f24250}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"432\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GGLS\",\"cohort\":\"1:jcl:\",\"cohortname\":\"Auto"
		"\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.b639cc0f057b0d472ba8827f557f9a745e640af0a4ccf5d3a7c77e944343ae6e\"}]},\"ping\":{\"ping_freshness\":\"{c6420df7-8ef0-4050-95ec-1e56a08014c9}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"8528\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"GGLS\",\"cohort\":\"1:w59:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\""
		"1.c64c9c1008f3ba5f6e18b3ca524bc98dcd8acfae0a2720a8f1f3ef0f8d643d05\"}]},\"ping\":{\"ping_freshness\":\"{e43e7153-201b-469b-8477-4921db6806c8}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"2020.11.2.164946\"},{\"appid\":\"gonpemdgkjcecdgbnaabipppbmgfggbe\",\"brand\":\"GGLS\",\"cohort\":\"1:z1x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.48fecfa3c6f59eb6c34fdd5e8f19e0678699e2f27dc8ebfa7025c246d4575c68\"}]},\"ping\":{\""
		"ping_freshness\":\"{879f9145-e636-43a1-bb23-5454dd58894c}\",\"rd\":6243},\"updatecheck\":{},\"version\":\"2024.1.17.0\"},{\"appid\":\"niikhdgajlphfehepabhhblakbdgeefj\",\"brand\":\"GGLS\",\"cohort\":\"1:1uh3:\",\"cohortname\":\"Auto Main Cohort.\",\"enabled\":true,\"installdate\":6134,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.738f6ed18eb59593934e529fa42f819ee99067eb187a687a24c2a940bae078d3\"}]},\"ping\":{\"ping_freshness\":\"{ab63f679-b5b3-49b6-a3de-0a8ad23558eb}\",\"rd\":6243},\""
		"updatecheck\":{},\"version\":\"2024.1.31.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":12,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.19045.3324\"},\"prodversion\":\"121.0.6167.140\",\"protocol\":\"3.1\",\"requestid\":\"{bb304706-d877-4f41-a23a-d3652b1d8388}\",\"sessionid\":\""
		"{bf8b3531-2e98-4113-915d-10d0d5be7452}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"laststarted\":0,\"name\":\"ChromiumUpdater\",\"updatepolicy\":-1,\"version\":\"123.0.6268.0\"},\"updaterversion\":\"121.0.6167.140\"}}", 
		EXTRARES, 
		"Url=https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT375qtPUYZr0WqxFfh87bLvb-B0jFIiul_rGBFJyMb2eP8yx_JZy5Z_6c&s=10", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT5bCs10a0XxK1ikEHN655AT_iHkXWJhAsmMUB_IEk&s=10", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRfwK31jSJoDS3wX4ZH2v5k49PLfabZSu90SO1eas4kL7IzpqiVbtXHE2Q&s=10", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSt4Zvuqg17L8xiVfbOLSa2Ljl60znIOJHhMXuDqX70yrRBHrTowpAOX2w&s=10", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://lh5.googleusercontent.com/p/AF1QipORjSliv1rRditQBc53zc97FH9h9Gm-56kJvMQH=w92-h92-n-k-no", "Referer=https://www.google.com/", ENDITEM, 
		LAST);

	lr_think_time(11);

	web_custom_request("json_2", 
		"URL=https://update.googleapis.com/service/update2/json", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GGLS\",\"cohort\":\"1:jcl:\",\"cohortname\":\"Auto\",\"enabled\":true,\"event\":[{\"download_time_ms\":16263,\"downloaded\":2130,\"downloader\":\"bits\",\"eventresult\":1,\"eventtype\":14,\"nextversion\":\"8529\",\"previousversion\":\"8528\",\"total\":2130,\"url\":\"http://edgedl.me.gvt1.com/edgedl/diffgen-puffin/"
		"hfnkpimlhhgieaddgfemjhofmfblmnib/1.bda4d85c5aed0b1f9273f8a7bd2a922e52bc884d684ff820edc096cdf1656eb4/1.b639cc0f057b0d472ba8827f557f9a745e640af0a4ccf5d3a7c77e944343ae6e/593c8ae791c2cd96580e06e311700e9a15ac70646ca31c848273d96d622568ba.puff\"},{\"diffresult\":1,\"eventresult\":1,\"eventtype\":3,\"nextfp\":\"1.bda4d85c5aed0b1f9273f8a7bd2a922e52bc884d684ff820edc096cdf1656eb4\",\"nextversion\":\"8529\",\"previousfp\":\"1.b639cc0f057b0d472ba8827f557f9a745e640af0a4ccf5d3a7c77e944343ae6e\",\""
		"previousversion\":\"8528\"}],\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.bda4d85c5aed0b1f9273f8a7bd2a922e52bc884d684ff820edc096cdf1656eb4\"}]},\"version\":\"8529\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":12,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\""
		"10.0.19045.3324\"},\"prodversion\":\"121.0.6167.140\",\"protocol\":\"3.1\",\"requestid\":\"{70052b96-f981-487d-b4ca-c7f71eca8f42}\",\"sessionid\":\"{bf8b3531-2e98-4113-915d-10d0d5be7452}\",\"updaterversion\":\"121.0.6167.140\"}}", 
		LAST);

	return 0;
}