vuser_end()
{

	/* logout */

	lr_think_time(15);

	web_url("logout", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/logout", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_custom_request("logout_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/users/logout", 
		"Method=POST", 
		"Resource=0", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/logout", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_url("thinking-tester-contact-list.herokuapp.com_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/", 
		"Resource=0", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/logout", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_concurrent_start(NULL);

	web_url("login.js", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/js/login.js", 
		"Resource=1", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/", 
		"Snapshot=t16.inf", 
		LAST);

	web_url("thinkingTesterLogo.png", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/img/thinkingTesterLogo.png", 
		"Resource=1", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/", 
		"Snapshot=t17.inf", 
		LAST);

	web_concurrent_end(NULL);

	return 0;
}