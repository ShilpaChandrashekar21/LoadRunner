Action()
{

	/* signup */

	lr_think_time(20);

	web_url("addUser", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/addUser", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	/* firstname */

	/* lastname */

	lr_think_time(34);

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=13:X3NvK_ZX1Ndk4t1KJOE3dv_lYo3RCtVh3gyjRB3KdJ4&cup2hreq=ac12ae21c23385eaed95f79186c0f8503a5db340f25f3697e5c8d2fc035ce606", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.30f5f886b824ca1efde5174370fc03cab3c02e9c309bc381857430f5843a510b\"}]},\"ping\":{\"ping_freshness\":\"{d25d931b-fdf3-4797-aa4e-bb7eeb7a6bcb}\",\"rd\":6251},\"updatecheck\":{},\"version\":\"1.3.36.311\"},{\"appid\":\""
		"neifaoindggfcjicffkgpmnlppeffabd\",\"brand\":\"GGLS\",\"cohort\":\"1:1299:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.c900ba9a2d8318263fd43782ee6fd5fb50bad78bf0eb2c972b5922c458af45ed\"}]},\"ping\":{\"ping_freshness\":\"{01afe2b5-cd58-42c5-99e3-5b51856edd89}\",\"rd\":6251},\"updatecheck\":{},\"version\":\"1.0.2738.0\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"GGLS\",\"cohort\":\"1:1zdx:\",\"cohortname"
		"\":\"Chrome 106+\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{78af137d-c6ab-4ba2-ba69-31fce8be76ff}\",\"rd\":6251},\"updatecheck\":{},\"version\":\"4.10.2710.0\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"GGLS\",\"cohort\":\"1:bm1:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.cd1978742a4afdbaaa15bf712d5c90bef4144caa99024df98f6a9ad58043ae85\"}]},\"ping\":{\""
		"ping_freshness\":\"{978266da-e13b-4c33-b767-dadbf7e125d6}\",\"rd\":6251},\"updatecheck\":{},\"version\":\"9.49.1\"},{\"accept_locale\":\"ENGB500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"GGLS\",\"cohort\":\"1:s6f/20ol:20or@0.5\",\"cohortname\":\"Rollout\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.8069f8805123f74944304604381770bb694317c9e1044e096f540222dc56c0f6\"}]},\"ping\":{\"ping_freshness\":\""
		"{b210d3a5-0049-45f9-a28f-b6e32e1efe45}\",\"rd\":6251},\"updatecheck\":{},\"version\":\"20230923.567854667.14\"},{\"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"GGLS\",\"cohort\":\"1:lwl:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.d714e27bbcdedab3f9f9ca92462ee6dc8ca779849aefdd27af92009a9d55a38f\"}]},\"ping\":{\"ping_freshness\":\"{90711087-d562-4ab4-8ae3-db9ab4a5c100}\",\"rd\":6251},\"updatecheck\":{},\""
		"version\":\"433\"},{\"appid\":\"kiabhabjdbkjdpjbpigfodbdjmbglcoo\",\"brand\":\"GGLS\",\"cohort\":\"1:v3l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6134,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.4a6508925b2ffec931c1e3931ddeb15ca41d820a8264cd5a962b526e9932bcdf\"}]},\"ping\":{\"ping_freshness\":\"{cefd7105-f0b9-47a6-9c68-344dea569e6e}\",\"rd\":6251},\"updatecheck\":{},\"version\":\"2024.1.2.1\"},{\"appid\":\"niikhdgajlphfehepabhhblakbdgeefj\",\"brand\":\"GGLS\",\""
		"cohort\":\"1:1uh3:\",\"cohortname\":\"Auto Main Cohort.\",\"enabled\":true,\"installdate\":6134,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.396f0c6d34d7135fea2ed14b699555b8f2dfb667e899ce8c79850d18760e8f06\"}]},\"ping\":{\"ping_freshness\":\"{6294b75d-526c-4df3-914b-af29f6635bf9}\",\"rd\":6251},\"updatecheck\":{},\"version\":\"2024.2.7.0\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"GGLS\",\"cohort\":\"1:j5l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\""
		":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.fd515ec0dc30d25a09641b8b83729234bc50f4511e35ce17d24fd996252eaace\"}]},\"ping\":{\"ping_freshness\":\"{956e4790-1776-4ed5-8510-5bc7113f7af1}\",\"rd\":6251},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"GGLS\",\"cohort\":\"1:cux:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\""
		"1.f4f1eb04881095d1cc8f2e1799a8144c10476dc1088a03ecdb4418644040a554\"}]},\"ping\":{\"ping_freshness\":\"{93490ee9-cf03-4df2-a69d-79560ba697d8}\",\"rd\":6251},\"updatecheck\":{},\"version\":\"63\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GGLS\",\"cohort\":\"1:jcl:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.90f54a8ca8c3135f647fedbb5f38ecadbbae4d45dafc3b73cde0c96d924a1773\"}]},\"ping\":{\"ping_freshness"
		"\":\"{81c048e5-66eb-4830-86ec-ab80394e3a02}\",\"rd\":6251},\"updatecheck\":{},\"version\":\"8531\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.3a118962ef814c91f6476bb9f0de58afa63103af6ac1b8729be9b39a86789e96\"}]},\"ping\":{\"ping_freshness\":\"{a2481c48-e89d-4ae5-bfd0-420261dc9249}\",\"rd\":6251},\"updatecheck\":{},\"version\":\"1.0.0.15\"},{\"appid\":\""
		"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\":\"GGLS\",\"cohort\":\"1:10zr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{a03a8821-9c60-466c-aba3-05ec88fe012e}\",\"rd\":6251},\"updatecheck\":{},\"version\":\"1.0.7.1652906823\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"GGLS\",\"cohort\":\"1:ofl:\",\"cohortname\":\"stable64\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\""
		"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{bc138c0b-2245-4248-98ee-42433a268aaf}\",\"rd\":6251},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\",\"brand\":\"GGLS\",\"cohort\":\"1:18ql:\",\"cohortname\":\"Auto Stage3\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.9324e37832b4647cfe6dd5c305addbd1aebad06a25acf8cab9423efe9424cbf2\"}]},\""
		"ping\":{\"ping_freshness\":\"{454c7bf2-b273-47c2-b9db-d06a55c5235c}\",\"rd\":6251},\"updatecheck\":{},\"version\":\"857\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"GGLS\",\"cohort\":\"1:s7x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.363351f0d0ca05b48f43d4adac95ad01d955bb2988c015733e70e09625d47065\"}]},\"ping\":{\"ping_freshness\":\"{3bbb2bdb-be6e-400a-ac1d-98552fab6aae}\",\"rd\":6251},\"updatecheck\""
		":{},\"version\":\"3018\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"GGLS\",\"cohort\":\"1:ut9/1a0f:23ml@0.1\",\"cohortname\":\"M108 and Above\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.c45cd56a0a8da0883c8f9757b31891d6c628f38cb80724015ffdf33b419a73f3\"}]},\"ping\":{\"ping_freshness\":\"{1847798a-bffc-46e2-a248-61fbb14922da}\",\"rd\":6251},\"updatecheck\":{},\"version\":\"2023.11.27.1202\"},{\"appid\":\""
		"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"GGLS\",\"cohort\":\"1:wvr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.c52c62a7c50daf7d3f73ec16977cd4b0ea401710807d5dbe3850941dd1b73a70\"}]},\"ping\":{\"ping_freshness\":\"{d8fc7a08-215b-42b8-b150-2738a484b19a}\",\"rd\":6251},\"updatecheck\":{},\"version\":\"120.0.6050.0\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"GGLS\",\"cohort\":\"1:w0x:\",\"cohortname"
		"\":\"All users\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.545666a4efd056351597bb386aea1368105ededc976ed5650d8682daab9f37ff\"}]},\"ping\":{\"ping_freshness\":\"{c48c0f51-fe44-4fe1-9c1c-835937463733}\",\"rd\":6251},\"updatecheck\":{},\"version\":\"3\"},{\"appid\":\"jflhchccmppkfebkiaminageehmchikm\",\"brand\":\"GGLS\",\"cohort\":\"1:26yf:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6148,\"lang\":\"en-GB\",\"packages\":{\""
		"package\":[{\"fp\":\"1.fd0c10a9d39acddc0fd6a083a23ff8a1521d45ac1328d60a7bd1a89b379b82bc\"}]},\"ping\":{\"ping_freshness\":\"{5924d2ba-2b4d-4e3b-81e4-0c7a7c27b4df}\",\"rd\":6251},\"updatecheck\":{},\"version\":\"2024.2.10.1\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"GGLS\",\"cohort\":\"1:w59:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.c64c9c1008f3ba5f6e18b3ca524bc98dcd8acfae0a2720a8f1f3ef0f8d643d05\"}"
		"]},\"ping\":{\"ping_freshness\":\"{c2d2a2fe-3b22-4f3f-8484-3095fc371a17}\",\"rd\":6251},\"updatecheck\":{},\"version\":\"2020.11.2.164946\"},{\"appid\":\"gonpemdgkjcecdgbnaabipppbmgfggbe\",\"brand\":\"GGLS\",\"cohort\":\"1:z1x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.06e71f675912f15e683ea65e2a1ec902ff07d67953b8dbf4542f93baf98a29bc\"}]},\"ping\":{\"ping_freshness\":\"{bb66664f-7985-4499-a298-5d4e70e96c56}\",\"rd\""
		":6251},\"updatecheck\":{},\"version\":\"2024.2.8.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":12,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.19045.3324\"},\"prodversion\":\"121.0.6167.161\",\"protocol\":\"3.1\",\"requestid\":\"{e21bd039-bb0a-4df4-bf43-1b425899ecce}\",\"sessionid\":\""
		"{4cc899a5-8ab7-4e9a-ac21-14a35853648f}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"laststarted\":0,\"name\":\"ChromiumUpdater\",\"updatepolicy\":-1,\"version\":\"123.0.6288.0\"},\"updaterversion\":\"121.0.6167.161\"}}", 
		LAST);

	/* email */

	/* password */

	web_add_cookie("NID=511=qpCCRrAbQQVT_1iBN3tAmHhP2KTY6jJNDp7vd7mRKg5yrFJqKC3ndYydLQ8fsvmYdfAJuU2IRrUQRVdS_e4EXpg3pnRbmX4zL4X6b-BXN7rmkOEfEYY2YWzLhGnOb5xK_Z3Jc58VpRAS7J8VCYYo58Aknex9Q9gXRKoVLOKi88s; DOMAIN=sb-ssl.google.com");

	lr_think_time(31);

	web_custom_request("login", 
		"URL=https://sb-ssl.google.com/safebrowsing/clientreport/login?key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=application/octet-stream", 
		"BodyBinary=\n:https://thinking-tester-contact-list.herokuapp.com/addUser\\x10\\x02\\x1A\\xB1\\x02\\x08\\x00\\x1A:https://thinking-tester-contact-list.herokuapp.com/addUser \\x01*\\x93\\x01\n:https://thinking-tester-contact-list.herokuapp.com/addUser\\x10\\x01\\x1A\r54.146.248.82\"3https://thinking-tester-contact-list.herokuapp.com/0\\x009\\x00p\\x82\\xDF\\xC6\\xD9xBP\\x03X\\x00p\\x00*Y\n3https://thinking-tester-contact-list.herokuapp.com/\\x10\\x02\\x1A\r54.146.248.82\""
		"\\x000\\x009\\x00\\x10\\xDA\\xD9\\xC6\\xD9xBP\\x01X\\x01p\\x00\"\\x06(\\x012\\x02\\x10\\x04(\\x012a\\x08\\x03\\x10\\x00(\\x020\\x008\\x01@\\x00J\\x1DChrome/121.0.6167.161/WindowsP\\x01X\\x01`\\x00r+\\x08\\x01\\x10\\xB3\\xF0\\xBB\\xE3\\xD91\\x1A }\\xFD\\xF7\\xB2f\\xC5\\xDFx\\xB1=\\x7F\\xD2^\\x0F=rN\\x89\\xA3\\xEB\r\\xEE4\\xCD\\xF0s&\\xAB\\xE1\\xE8\\xC8\\xEB\\x90\\x01\\x008\\x00B\ttext/htmlZ\\x00b\\xEE\\x02\n\\x18\n\rPageTerm=user\\x11\\x00\\x00\\x00\\x00\\x00\\x00\\xF0?\n!\n"
		"\\x16PageImgOtherDomainFreq\\x11\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\n\\x1C\n\\x11PageHasTextInputs\\x11\\x00\\x00\\x00\\x00\\x00\\x00\\xF0?\n\\x17\n\\x0CPageHasForms\\x11\\x00\\x00\\x00\\x00\\x00\\x00\\xF0?\n\\x1F\n\\x14UrlPathToken=addUser\\x11\\x00\\x00\\x00\\x00\\x00\\x00\\xF0?\n9\n.UrlOtherHostToken=thinking-tester-contact-list\\x11\\x00\\x00\\x00\\x00\\x00\\x00\\xF0?\n\\x1E\n\\x13UrlDomain=herokuapp\\x11\\x00\\x00\\x00\\x00\\x00\\x00\\xF0?\n\\x1C\n"
		"\\x11PageHasPswdInputs\\x11\\x00\\x00\\x00\\x00\\x00\\x00\\xF0?\n\\x15\n\nUrlTld=com\\x11\\x00\\x00\\x00\\x00\\x00\\x00\\xF0?\\x12E\\xFD\\xA6\\xFCG\\xB5\\x82\\xC2\\x8D\\x04\\x89\\xE1\\xE0\\xA7\\x04\\xF2\\xFE\\xC7\\xE1\\x04\\xEE\\xEB\\xE7\\xA2\\x06\\xC6\\xEC\\xA5\\x80\\x07\\x99\\xC0\\xB2\\xE9\\x07\\x8E\\x84\\x99\\xBD\\x08\\xAE\\x8B\\xC2\\xFD\\x08\\x99\\xBB\\xDE\\xAB\t\\xFE\\xD7\\x87\\xBE\t\\x99\\xD3\\xBF\\xEA\\x0B\\x9C\\xA6\\x8C\\xBB\\x0E\\xCE\\x84\\xBB\\xDF\\x0E\\x18\""
		"h\\x01r\\x06\\x08\\x00\\x10\\x000\\x00", 
		LAST);

	/* submit */

	lr_think_time(12);

	web_custom_request("users", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/users", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/addUser", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"firstName\":\"Shilpa\",\"lastName\":\"C\",\"email\":\"abcd@hotmail.com\",\"password\":\"Shilpa21\"}", 
		LAST);

	web_url("contactList", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/addUser", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("contacts", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contacts", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	/* add new contact */

	lr_think_time(17);

	web_url("addContact", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/addContact", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	lr_think_time(11);

	web_custom_request("contacts_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contacts", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/addContact", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"firstName\":\"john\",\"lastName\":\"doe\",\"birthdate\":\"2000-12-13\",\"email\":\"abx@df.com\",\"phone\":\"1234567890\"}", 
		LAST);

	web_url("contactList_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Resource=0", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/addContact", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("contacts_3", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contacts", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}
