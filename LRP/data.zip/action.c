Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("loadrunnertips.com", 
		"URL=http://loadrunnertips.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("collect", 
		"URL=https://www.google-analytics.com/j/collect?v=1&_v=j101&a=1022608586&t=pageview&_s=1&dl=http%3A%2F%2Floadrunnertips.com%2F&ul=en-gb&de=UTF-8&dt="
		"Load%20Runner%20Tips-%20Performance%20testing%2C%20load%20testing%2C%20stress%20testing%2C%20soak%20testing%2C%20endurances%20testing%20tool%2CVuGen%20script%20creation%2C%20Load%20Runner%20Correlation%2C%20LR%20Scripting%2C%20Load%20Runner%20parameterization%2C%20Load%20Runner%20transaction%20naming%2CLR%20think%20time%2C%20LR%20transaction%2C%20web%20reg%20save%20param%2C%20Web%20reg%20find%2C%20Lr%20pacing&sd=24-bit&sr=1280x720&vp=1263x593&je=0&_u=IEBAAEABAAAAACAAI~&jid=2078880576&gjid="
		"586369228&cid=980661036.1708337501&tid=UA-54539864-2&_gid=1672187656.1708337501&_r=1&_slc=1&z=700494663", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://loadrunnertips.com/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		LAST);

	web_custom_request("collect_2", 
		"URL=https://www.google-analytics.com/g/collect?v=2&tid=G-7JE8RPG7Y7&gtm=45je42e0v9134516205za200&_p=1708337501158&gcd=13l3l3l3l2&npa=0&dma=0&ul=en-gb&sr=1280x720&cid=980661036.1708337501&are=1&pscdl=noapi&_eu=ABAI&_s=1&dl=http%3A%2F%2Floadrunnertips.com%2F&dt="
		"Load%20Runner%20Tips-%20Performance%20testing%2C%20load%20testing%2C%20stress%20testing%2C%20soak%20testing%2C%20endurances%20testing%20tool%2CVuGen%20script%20creation%2C%20Load%20Runner%20Correlation%2C%20LR%20Scripting%2C%20Load%20Runner%20parameterization%2C%20Load%20Runner%20transaction%20naming%2CLR%20think%20time%2C%20LR%20transaction%2C%20web%20reg%20save%20param%2C%20Web%20reg%20find%2C%20Lr%20pacing&sid=1708337502&sct=1&seg=0&en=page_view&_fv=1&_ss=1&_ee=1&tfd=4531", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://loadrunnertips.com/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	/* correlation  */

	web_add_cookie("_ga=GA1.2.980661036.1708337501; DOMAIN=loadrunnertips.com");

	web_add_cookie("_gid=GA1.2.1672187656.1708337501; DOMAIN=loadrunnertips.com");

	web_add_cookie("_gat=1; DOMAIN=loadrunnertips.com");

	web_add_cookie("_ga_7JE8RPG7Y7=GS1.2.1708337502.1.0.1708337502.0.0.0; DOMAIN=loadrunnertips.com");

	lr_think_time(18);

	web_url("LoadRunner_Correlation_Challenge_Mod.aspx", 
		"URL=http://loadrunnertips.com/LoadRunner_Correlation_Challenge_Mod.aspx", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://loadrunnertips.com/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("collect_3", 
		"URL=https://www.google-analytics.com/j/collect?v=1&_v=j101&a=1527091654&t=pageview&_s=1&dl=http%3A%2F%2Floadrunnertips.com%2FLoadRunner_Correlation_Challenge_Mod.aspx&ul=en-gb&de=UTF-8&dt=LoadRunner%3A%20Correlation%20Challenge&sd=24-bit&sr=1280x720&vp=1263x593&je=0&_u=AACAAEABAAAAACAAI~&jid=&gjid=&cid=980661036.1708337501&tid=UA-54539864-2&_gid=1672187656.1708337501&_slc=1&z=2133210676", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://loadrunnertips.com/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		LAST);

	lr_think_time(5);

	web_custom_request("collect_4", 
		"URL=https://www.google-analytics.com/g/collect?v=2&tid=G-7JE8RPG7Y7&gtm=45je42e0v9134516205za200&_p=1708337524723&gcd=13l3l3l3l2&npa=0&dma=0&ul=en-gb&sr=1280x720&cid=980661036.1708337501&are=1&pscdl=noapi&_eu=ABAI&_s=1&dl=http%3A%2F%2Floadrunnertips.com%2FLoadRunner_Correlation_Challenge_Mod.aspx&dt=LoadRunner%3A%20Correlation%20Challenge&sid=1708337502&sct=1&seg=1&en=page_view&_ee=1&_et=1&tfd=9374", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://loadrunnertips.com/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	/* start */

	web_add_cookie("_ga_7JE8RPG7Y7=GS1.2.1708337502.1.1.1708337524.0.0.0; DOMAIN=loadrunnertips.com");

	lr_think_time(4);

	web_submit_data("LoadRunner_Correlation_Challenge_Mod.aspx_2", 
		"Action=http://loadrunnertips.com/LoadRunner_Correlation_Challenge_Mod.aspx", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://loadrunnertips.com/LoadRunner_Correlation_Challenge_Mod.aspx", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__VIEWSTATE", "Value=/wEPDwUJOTg3MDg5NjY4ZGSpeujMXq9dhhW/s7hcdKBqtNppWxSDRQiCpjYtl/zM8Q==", ENDITEM, 
		"Name=__VIEWSTATEGENERATOR", "Value=3074961D", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value=/wEdAAI8SKNQprDFK8rsi0EJ5/yGnlbekVM3R/a0oKRYPLuOREujrpNMsu4xbEP1zwz+bV66MXj1n2GeMVkJ2V0pBksg", ENDITEM, 
		"Name=ctl00$head$btnStart", "Value=Start", ENDITEM, 
		LAST);

	/* number */

	lr_think_time(7);

	web_custom_request("collect_5", 
		"URL=https://www.google-analytics.com/j/collect?v=1&_v=j101&a=1251816141&t=pageview&_s=1&dl=http%3A%2F%2Floadrunnertips.com%2FLoadRunner_Correlation_Challenge_Mod.aspx&ul=en-gb&de=UTF-8&dt=LoadRunner%3A%20Correlation%20Challenge&sd=24-bit&sr=1280x720&vp=1263x593&je=0&_u=AACAAEABAAAAACAAI~&jid=&gjid=&cid=980661036.1708337501&tid=UA-54539864-2&_gid=1672187656.1708337501&_slc=1&z=705471383", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://loadrunnertips.com/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		LAST);

	web_custom_request("collect_6", 
		"URL=https://www.google-analytics.com/g/collect?v=2&tid=G-7JE8RPG7Y7&gtm=45je42e0v9134516205za200&_p=1708337543639&gcd=13l3l3l3l2&npa=0&dma=0&ul=en-gb&sr=1280x720&cid=980661036.1708337501&are=1&pscdl=noapi&_eu=ABAI&_s=1&dl=http%3A%2F%2Floadrunnertips.com%2FLoadRunner_Correlation_Challenge_Mod.aspx&dt=LoadRunner%3A%20Correlation%20Challenge&sid=1708337502&sct=1&seg=1&en=page_view&_ee=1&tfd=14235", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://loadrunnertips.com/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_add_cookie("_ga_7JE8RPG7Y7=GS1.2.1708337502.1.1.1708337543.0.0.0; DOMAIN=loadrunnertips.com");

	web_submit_data("LoadRunner_Correlation_Challenge_Mod.aspx_3", 
		"Action=http://loadrunnertips.com/LoadRunner_Correlation_Challenge_Mod.aspx", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://loadrunnertips.com/LoadRunner_Correlation_Challenge_Mod.aspx", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__VIEWSTATE", "Value=/wEPDwUJOTg3MDg5NjY4ZGSpeujMXq9dhhW/s7hcdKBqtNppWxSDRQiCpjYtl/zM8Q==", ENDITEM, 
		"Name=__VIEWSTATEGENERATOR", "Value=3074961D", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value=/wEdAAM8SKNQprDFK8rsi0EJ5/yGEZwAPPXs+fTr6SGYYqMh2jrXPBqUZcs4yqSWpp6/FIQD1Rc0mWY9uuZuEzjglRSMxfhFsuoZ/uWxprC3MuRsOg==", ENDITEM, 
		"Name=ctl00$head$txtMacigNo", "Value=9694", ENDITEM, 
		"Name=ctl00$head$btnNext", "Value=Next", ENDITEM, 
		LAST);

	web_custom_request("collect_7", 
		"URL=https://www.google-analytics.com/j/collect?v=1&_v=j101&a=805961319&t=pageview&_s=1&dl=http%3A%2F%2Floadrunnertips.com%2FLoadRunner_Correlation_Challenge_Mod.aspx&ul=en-gb&de=UTF-8&dt=LoadRunner%3A%20Correlation%20Challenge&sd=24-bit&sr=1280x720&vp=1263x593&je=0&_u=AACAAEABAAAAACAAI~&jid=&gjid=&cid=980661036.1708337501&tid=UA-54539864-2&_gid=1672187656.1708337501&_slc=1&z=1894909441", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://loadrunnertips.com/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		LAST);

	lr_think_time(5);

	web_custom_request("collect_8", 
		"URL=https://www.google-analytics.com/g/collect?v=2&tid=G-7JE8RPG7Y7&gtm=45je42e0v9134516205za200&_p=1708337550814&gcd=13l3l3l3l2&npa=0&dma=0&ul=en-gb&sr=1280x720&cid=980661036.1708337501&are=1&pscdl=noapi&_eu=ABAI&_s=1&dl=http%3A%2F%2Floadrunnertips.com%2FLoadRunner_Correlation_Challenge_Mod.aspx&dt=LoadRunner%3A%20Correlation%20Challenge&sid=1708337502&sct=1&seg=1&en=page_view&_ee=1&tfd=5475", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://loadrunnertips.com/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	/* value */

	lr_think_time(4);

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=13:cODIJxlfe1yHv_Ipg9P-UgmlcAnO0j1P_mvqWmuUGek&cup2hreq=7ec0b98eee3e4ceba79d159f6016ddd6c4dbdeaa8d56461f80e84273b7e63715", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.30f5f886b824ca1efde5174370fc03cab3c02e9c309bc381857430f5843a510b\"}]},\"ping\":{\"ping_freshness\":\"{ff9557f0-830b-489d-9bcb-8012b9660d05}\",\"rd\":6258},\"updatecheck\":{},\"version\":\"1.3.36.311\"},{\"appid\":\""
		"neifaoindggfcjicffkgpmnlppeffabd\",\"brand\":\"GGLS\",\"cohort\":\"1:1299:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.c900ba9a2d8318263fd43782ee6fd5fb50bad78bf0eb2c972b5922c458af45ed\"}]},\"ping\":{\"ping_freshness\":\"{aa1e0dfe-13cb-449a-8be2-204b4ce9ce26}\",\"rd\":6258},\"updatecheck\":{},\"version\":\"1.0.2738.0\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"GGLS\",\"cohort\":\"1:1zdx:\",\"cohortname"
		"\":\"Chrome 106+\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{5e57a8ff-4aef-4edb-b474-4ebfd925634d}\",\"rd\":6258},\"updatecheck\":{},\"version\":\"4.10.2710.0\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"GGLS\",\"cohort\":\"1:bm1:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.cd1978742a4afdbaaa15bf712d5c90bef4144caa99024df98f6a9ad58043ae85\"}]},\"ping\":{\""
		"ping_freshness\":\"{68a3c0f8-adfe-410b-87ce-5edcd3cef495}\",\"rd\":6258},\"updatecheck\":{},\"version\":\"9.49.1\"},{\"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"GGLS\",\"cohort\":\"1:lwl:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.04dfbee1ec2fd167512805dedf3fa2a823dc28fe9fa2c97a74e664b38486110f\"}]},\"ping\":{\"ping_freshness\":\"{1df71394-2845-40ac-89b0-39521ae4f9ce}\",\"rd\":6258},\"updatecheck\":{},\""
		"version\":\"434\"},{\"accept_locale\":\"ENGB500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"GGLS\",\"cohort\":\"1:s6f/20ol:20or@0.5\",\"cohortname\":\"Rollout\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.8069f8805123f74944304604381770bb694317c9e1044e096f540222dc56c0f6\"}]},\"ping\":{\"ping_freshness\":\"{1b370e73-2de3-4191-b17d-983f2263c080}\",\"rd\":6258},\"updatecheck\":{},\"version\":\"20230923.567854667.14\"},{\"appid\":"
		"\"kiabhabjdbkjdpjbpigfodbdjmbglcoo\",\"brand\":\"GGLS\",\"cohort\":\"1:v3l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6134,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.4a6508925b2ffec931c1e3931ddeb15ca41d820a8264cd5a962b526e9932bcdf\"}]},\"ping\":{\"ping_freshness\":\"{d1bf4cb6-0d1e-4504-bf68-4ae073cfa13b}\",\"rd\":6258},\"updatecheck\":{},\"version\":\"2024.1.2.1\"},{\"appid\":\"niikhdgajlphfehepabhhblakbdgeefj\",\"brand\":\"GGLS\",\"cohort\":\"1:1uh3:\",\""
		"cohortname\":\"Auto Main Cohort.\",\"enabled\":true,\"installdate\":6134,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.338cbd67983bc23dfdcae48f34706ac81e378161918137c5242db2175f52d94e\"}]},\"ping\":{\"ping_freshness\":\"{30e2cce7-be17-4bfb-aa4d-7dcb6f52059b}\",\"rd\":6258},\"updatecheck\":{},\"version\":\"2024.2.14.0\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"GGLS\",\"cohort\":\"1:j5l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB"
		"\",\"packages\":{\"package\":[{\"fp\":\"1.fd515ec0dc30d25a09641b8b83729234bc50f4511e35ce17d24fd996252eaace\"}]},\"ping\":{\"ping_freshness\":\"{53999f61-1522-4452-841d-36e06f7b895c}\",\"rd\":6258},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"GGLS\",\"cohort\":\"1:cux:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\""
		"1.f4f1eb04881095d1cc8f2e1799a8144c10476dc1088a03ecdb4418644040a554\"}]},\"ping\":{\"ping_freshness\":\"{09b36480-1101-4e6c-9429-14a10ba80c9d}\",\"rd\":6258},\"updatecheck\":{},\"version\":\"63\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.3a118962ef814c91f6476bb9f0de58afa63103af6ac1b8729be9b39a86789e96\"}]},\"ping\":{\"ping_freshness\":\""
		"{396659eb-13e5-4173-bcbd-9fc71a18c1e8}\",\"rd\":6258},\"updatecheck\":{},\"version\":\"1.0.0.15\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\":\"GGLS\",\"cohort\":\"1:10zr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{c0dad611-1a17-4c4e-be91-5df94a907646}\",\"rd\":6258},\"updatecheck\":{},\"version\":\"1.0.7.1652906823\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"GGLS\",\"cohort\":\"1:ofl:\",\""
		"cohortname\":\"stable64\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{df9a8903-a29f-47dd-81ab-b32aefaef0c9}\",\"rd\":6258},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GGLS\",\"cohort\":\"1:2879:\",\"cohortname\":\"Auto androidlowmem\",\"enabled\":true,\"installdate\":5887,\"lang\":\""
		"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.cb0c781d5870726b7b1c46b031524bd2f772e8cac9614a0dfad7c5b799be575d\"}]},\"ping\":{\"ping_freshness\":\"{c5816d00-3298-4816-84a1-53e190b6e0a2}\",\"rd\":6258},\"updatecheck\":{},\"version\":\"8556\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"GGLS\",\"cohort\":\"1:s7x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\""
		"1.af8fa6822a4a3a4aeaf78dd2b562b3b76ed3ef0b362f8ebc822df79717c996df\"}]},\"ping\":{\"ping_freshness\":\"{d3f16926-047f-4202-ba4d-4cf809fd7bdb}\",\"rd\":6258},\"updatecheck\":{},\"version\":\"3019\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"GGLS\",\"cohort\":\"1:ut9/1a0f:23ml@0.1\",\"cohortname\":\"M108 and Above\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.c45cd56a0a8da0883c8f9757b31891d6c628f38cb80724015ffdf33b419a73f3\"}]},\""
		"ping\":{\"ping_freshness\":\"{92526c5d-d8c5-48cb-bda0-2006bbd813df}\",\"rd\":6258},\"updatecheck\":{},\"version\":\"2023.11.27.1202\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"GGLS\",\"cohort\":\"1:wvr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.c52c62a7c50daf7d3f73ec16977cd4b0ea401710807d5dbe3850941dd1b73a70\"}]},\"ping\":{\"ping_freshness\":\"{b2fc47ed-0888-4d54-beb4-804ec24c4590}\",\"rd\":6258},\""
		"updatecheck\":{},\"version\":\"120.0.6050.0\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"GGLS\",\"cohort\":\"1:w0x:\",\"cohortname\":\"All users\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.545666a4efd056351597bb386aea1368105ededc976ed5650d8682daab9f37ff\"}]},\"ping\":{\"ping_freshness\":\"{a498c122-84b2-465f-bfd3-9a20bee2397a}\",\"rd\":6258},\"updatecheck\":{},\"version\":\"3\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\","
		"\"brand\":\"GGLS\",\"cohort\":\"1:18ql:\",\"cohortname\":\"Auto Stage3\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.4ccf4cac4c37dd966d3bee0b3a4137894eecde1b22a9d4e7ef07d5081b5cf67a\"}]},\"ping\":{\"ping_freshness\":\"{ab2c6616-ae40-4e10-aa65-cce5601f84dc}\",\"rd\":6258},\"updatecheck\":{},\"version\":\"867\"},{\"appid\":\"jflhchccmppkfebkiaminageehmchikm\",\"brand\":\"GGLS\",\"cohort\":\"1:26yf:\",\"cohortname\":\"Stable\",\"enabled\":true,\""
		"installdate\":6148,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.cb80f7697a4bf93f5ba730126c381fe89e37b6a264215bcbe4e12628b8940e98\"}]},\"ping\":{\"ping_freshness\":\"{448bb032-8d66-4b67-ae5e-a380588900a1}\",\"rd\":6258},\"updatecheck\":{},\"version\":\"2024.2.17.1\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"GGLS\",\"cohort\":\"1:w59:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\""
		"1.c64c9c1008f3ba5f6e18b3ca524bc98dcd8acfae0a2720a8f1f3ef0f8d643d05\"}]},\"ping\":{\"ping_freshness\":\"{751c633b-9e8a-41e3-8779-8d9142bb92a4}\",\"rd\":6258},\"updatecheck\":{},\"version\":\"2020.11.2.164946\"},{\"appid\":\"gonpemdgkjcecdgbnaabipppbmgfggbe\",\"brand\":\"GGLS\",\"cohort\":\"1:z1x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.7e7996864a74a4b8db2b59c559f924f321668848edbcb85386212a4901ef0e6e\"}]},\"ping\":{\""
		"ping_freshness\":\"{3fffb26b-b4f8-42c3-9afe-0753d6c9aca0}\",\"rd\":6258},\"updatecheck\":{},\"version\":\"2024.2.14.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":12,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.19045.3324\"},\"prodversion\":\"121.0.6167.185\",\"protocol\":\"3.1\",\""
		"requestid\":\"{45c62bcc-b388-4718-87bd-f47c3320c97b}\",\"sessionid\":\"{7a4d9068-a666-457a-97cb-f080fcf42d05}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"laststarted\":0,\"name\":\"ChromiumUpdater\",\"updatepolicy\":-1,\"version\":\"123.0.6288.0\"},\"updaterversion\":\"121.0.6167.185\"}}", 
		LAST);

	web_add_cookie("_ga_7JE8RPG7Y7=GS1.2.1708337502.1.1.1708337550.0.0.0; DOMAIN=loadrunnertips.com");

	web_url("LoadRunner_Correlation_Challenge_Mod.aspx_4", 
		"URL=http://loadrunnertips.com/LoadRunner_Correlation_Challenge_Mod.aspx?dd=1&game=Rugby%20Union", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://loadrunnertips.com/LoadRunner_Correlation_Challenge_Mod.aspx", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("collect_9", 
		"URL=https://www.google-analytics.com/j/collect?v=1&_v=j101&a=45689824&t=pageview&_s=1&dl=http%3A%2F%2Floadrunnertips.com%2FLoadRunner_Correlation_Challenge_Mod.aspx&ul=en-gb&de=UTF-8&dt=LoadRunner%3A%20Correlation%20Challenge&sd=24-bit&sr=1280x720&vp=1263x593&je=0&_u=AACAAEABAAAAACAAI~&jid=1805597704&gjid=1129185620&cid=980661036.1708337501&tid=UA-54539864-2&_gid=1672187656.1708337501&_r=1&_slc=1&z=1528155730", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://loadrunnertips.com/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		LAST);

	lr_think_time(5);

	web_custom_request("collect_10", 
		"URL=https://www.google-analytics.com/g/collect?v=2&tid=G-7JE8RPG7Y7&gtm=45je42e0v9134516205za200&_p=1708337563589&gcd=13l3l3l3l2&npa=0&dma=0&ul=en-gb&sr=1280x720&cid=980661036.1708337501&are=1&pscdl=noapi&_eu=ABAI&_s=1&dl=http%3A%2F%2Floadrunnertips.com%2FLoadRunner_Correlation_Challenge_Mod.aspx&dt=LoadRunner%3A%20Correlation%20Challenge&sid=1708337502&sct=1&seg=1&en=page_view&_ee=1&tfd=5745", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://loadrunnertips.com/", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_add_cookie("_ga_7JE8RPG7Y7=GS1.2.1708337502.1.1.1708337563.0.0.0; DOMAIN=loadrunnertips.com");

	web_submit_data("LoadRunner_Correlation_Challenge_Mod.aspx_5", 
		"Action=http://loadrunnertips.com/LoadRunner_Correlation_Challenge_Mod.aspx", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://loadrunnertips.com/LoadRunner_Correlation_Challenge_Mod.aspx", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__VIEWSTATE", "Value=/wEPDwUJOTg3MDg5NjY4ZGSpeujMXq9dhhW/s7hcdKBqtNppWxSDRQiCpjYtl/zM8Q==", ENDITEM, 
		"Name=__VIEWSTATEGENERATOR", "Value=3074961D", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value=/wEdAAI8SKNQprDFK8rsi0EJ5/yGnlbekVM3R/a0oKRYPLuOREujrpNMsu4xbEP1zwz+bV66MXj1n2GeMVkJ2V0pBksg", ENDITEM, 
		"Name=ctl00$head$btnStart", "Value=Start", ENDITEM, 
		LAST);

	web_custom_request("collect_11", 
		"URL=https://www.google-analytics.com/j/collect?v=1&_v=j101&a=2127601043&t=pageview&_s=1&dl=http%3A%2F%2Floadrunnertips.com%2FLoadRunner_Correlation_Challenge_Mod.aspx&ul=en-gb&de=UTF-8&dt=LoadRunner%3A%20Correlation%20Challenge&sd=24-bit&sr=1280x720&vp=1263x593&je=0&_u=AACAAEABAAAAACAAI~&jid=&gjid=&cid=980661036.1708337501&tid=UA-54539864-2&_gid=1672187656.1708337501&_slc=1&z=1692358002", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://loadrunnertips.com/", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		LAST);

	lr_think_time(5);

	web_custom_request("collect_12", 
		"URL=https://www.google-analytics.com/g/collect?v=2&tid=G-7JE8RPG7Y7&gtm=45je42e0v9134516205za200&_p=1708337571034&gcd=13l3l3l3l2&npa=0&dma=0&ul=en-gb&sr=1280x720&cid=980661036.1708337501&are=1&pscdl=noapi&_eu=ABAI&_s=1&dl=http%3A%2F%2Floadrunnertips.com%2FLoadRunner_Correlation_Challenge_Mod.aspx&dt=LoadRunner%3A%20Correlation%20Challenge&sid=1708337502&sct=1&seg=1&en=page_view&_ee=1&tfd=5477", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://loadrunnertips.com/", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_add_cookie("_ga_7JE8RPG7Y7=GS1.2.1708337502.1.1.1708337571.0.0.0; DOMAIN=loadrunnertips.com");

	web_submit_data("LoadRunner_Correlation_Challenge_Mod.aspx_6", 
		"Action=http://loadrunnertips.com/LoadRunner_Correlation_Challenge_Mod.aspx", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://loadrunnertips.com/LoadRunner_Correlation_Challenge_Mod.aspx", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__VIEWSTATE", "Value=/wEPDwUJOTg3MDg5NjY4ZGSpeujMXq9dhhW/s7hcdKBqtNppWxSDRQiCpjYtl/zM8Q==", ENDITEM, 
		"Name=__VIEWSTATEGENERATOR", "Value=3074961D", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value=/wEdAAM8SKNQprDFK8rsi0EJ5/yGEZwAPPXs+fTr6SGYYqMh2jrXPBqUZcs4yqSWpp6/FIQD1Rc0mWY9uuZuEzjglRSMxfhFsuoZ/uWxprC3MuRsOg==", ENDITEM, 
		"Name=ctl00$head$txtMacigNo", "Value=9935", ENDITEM, 
		"Name=ctl00$head$btnNext", "Value=Next", ENDITEM, 
		LAST);

	web_custom_request("collect_13", 
		"URL=https://www.google-analytics.com/j/collect?v=1&_v=j101&a=1646709471&t=pageview&_s=1&dl=http%3A%2F%2Floadrunnertips.com%2FLoadRunner_Correlation_Challenge_Mod.aspx&ul=en-gb&de=UTF-8&dt=LoadRunner%3A%20Correlation%20Challenge&sd=24-bit&sr=1280x720&vp=1263x593&je=0&_u=AACAAEABAAAAACAAI~&jid=&gjid=&cid=980661036.1708337501&tid=UA-54539864-2&_gid=1672187656.1708337501&_slc=1&z=1714283486", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://loadrunnertips.com/", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		LAST);

	web_add_cookie("_ga_7JE8RPG7Y7=GS1.2.1708337502.1.1.1708337578.0.0.0; DOMAIN=loadrunnertips.com");

	web_url("LoadRunner_Correlation_Challenge_Mod.aspx_7", 
		"URL=http://loadrunnertips.com/LoadRunner_Correlation_Challenge_Mod.aspx?dd=1&game=Volleyball", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://loadrunnertips.com/LoadRunner_Correlation_Challenge_Mod.aspx", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("collect_14", 
		"URL=https://www.google-analytics.com/g/collect?v=2&tid=G-7JE8RPG7Y7&gtm=45je42e0v9134516205za200&_p=1708337578636&gcd=13l3l3l3l2&npa=0&dma=0&ul=en-gb&sr=1280x720&cid=980661036.1708337501&are=1&pscdl=noapi&_eu=ABAI&_s=1&dl=http%3A%2F%2Floadrunnertips.com%2FLoadRunner_Correlation_Challenge_Mod.aspx&dt=LoadRunner%3A%20Correlation%20Challenge&sid=1708337502&sct=1&seg=1&en=page_view&_ee=1&tfd=3524", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://loadrunnertips.com/", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("collect_15", 
		"URL=https://www.google-analytics.com/j/collect?v=1&_v=j101&a=2141882811&t=pageview&_s=1&dl=http%3A%2F%2Floadrunnertips.com%2FLoadRunner_Correlation_Challenge_Mod.aspx%3Fdd%3D1%26game%3DVolleyball&ul=en-gb&de=UTF-8&dt=LoadRunner%3A%20Correlation%20Challenge&sd=24-bit&sr=1280x720&vp=1263x593&je=0&_u=AACAAEABAAAAACAAI~&jid=&gjid=&cid=980661036.1708337501&tid=UA-54539864-2&_gid=1672187656.1708337501&_slc=1&z=829408401", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://loadrunnertips.com/", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		LAST);

	lr_think_time(5);

	web_custom_request("collect_16", 
		"URL=https://www.google-analytics.com/g/collect?v=2&tid=G-7JE8RPG7Y7&gtm=45je42e0v9134516205za200&_p=1708337581914&gcd=13l3l3l3l2&npa=0&dma=0&ul=en-gb&sr=1280x720&cid=980661036.1708337501&are=1&pscdl=noapi&_eu=ABAI&_s=1&dl=http%3A%2F%2Floadrunnertips.com%2FLoadRunner_Correlation_Challenge_Mod.aspx%3Fdd%3D1%26game%3DVolleyball&dt=LoadRunner%3A%20Correlation%20Challenge&sid=1708337502&sct=1&seg=1&en=page_view&_ee=1&tfd=5470", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://loadrunnertips.com/", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	/* flight */

	web_add_cookie("_ga_7JE8RPG7Y7=GS1.2.1708337502.1.1.1708337581.0.0.0; DOMAIN=loadrunnertips.com");

	lr_think_time(26);

	web_submit_data("LoadRunner_Correlation_Challenge_Mod.aspx_8", 
		"Action=http://loadrunnertips.com/LoadRunner_Correlation_Challenge_Mod.aspx?dd=1&game=Volleyball", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://loadrunnertips.com/LoadRunner_Correlation_Challenge_Mod.aspx?dd=1&game=Volleyball", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__VIEWSTATE", "Value=/"
		"wEPDwUJOTg3MDg5NjY4ZBgBBR5fX0NvbnRyb2xzUmVxdWlyZVBvc3RCYWNrS2V5X18WFAUPY3RsMDAkaGVhZCRjaGsxBQ9jdGwwMCRoZWFkJGNoazIFD2N0bDAwJGhlYWQkY2hrMwUPY3RsMDAkaGVhZCRjaGs0BQ9jdGwwMCRoZWFkJGNoazUFD2N0bDAwJGhlYWQkY2hrNgUPY3RsMDAkaGVhZCRjaGs3BQ9jdGwwMCRoZWFkJGNoazgFD2N0bDAwJGhlYWQkY2hrOQUQY3RsMDAkaGVhZCRjaGsxMAUQY3RsMDAkaGVhZCRjaGsxMQUQY3RsMDAkaGVhZCRjaGsxMgUQY3RsMDAkaGVhZCRjaGsxMwUQY3RsMDAkaGVhZCRjaGsxNAUQY3RsMDAkaGVhZCRjaGsxNQUQY3RsMDAkaGVhZCRjaGsxNgUQY3RsMDAkaGVhZCRjaGsxNwUQY3RsMDAkaGVhZCRjaGsxOAUQY3RsMDAkaGV"
		"hZCRjaGsxOQUQY3RsMDAkaGVhZCRjaGsyMLhH1qY+MDD68IqSSRGms9pTxa0s6qmXIUx6SWtOyBLU", ENDITEM, 
		"Name=__VIEWSTATEGENERATOR", "Value=3074961D", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value=/wEdABbrvUA5RuelHNFEFU92rxaMqasbxwl7lgdZZfZ2n+oFBQVQb/BqIrnuBsiTd5SBX0XDYFHBMur5v1vZ4LUwZUXEv1bMxkD35JfEKTUHLZw4URiuU4nLTwtj/r43949QF/fcXs3H4McaH100kUT9gcPbmpgAqjKGNuaeCinRuZ1fUy+AnrQ09DAotZNMecAuJqp7WQG8SNPlN0mV+BwfjWNo1u1qRUoE0ucmhZnEUyRDxJcIA7A2BTvsdZNVrY2UTuZixHoyjomtObKrCt06E5/UAoxFdFd6aX6eQs9i0oSTXDkt+Do6wOIA4KwaXE0pUgA2isLFBHeYufrtFtgXd6f0DGIM5YFnsJoM+HWSXfRSONHx4ZdtIVVepNuIcMSoJKpEnOUHlLp+"
		"oSuQ44YhcKDN8B20tHcNPS9okHrSEPNbXouIr9iCQfCWk3E3COVI0FitjCG6HyklgWzfDmV0vuRMIAMSETr/wl4Jt9mnGFRNAYhIpaX377s/QqyaL7CNne4=", ENDITEM, 
		"Name=ctl00$head$chk4", "Value=on", ENDITEM, 
		"Name=ctl00$head$chk6", "Value=on", ENDITEM, 
		"Name=ctl00$head$chk8", "Value=on", ENDITEM, 
		"Name=ctl00$head$chk9", "Value=on", ENDITEM, 
		"Name=ctl00$head$chk12", "Value=on", ENDITEM, 
		"Name=ctl00$head$btnNext3", "Value=Next", ENDITEM, 
		LAST);

	web_custom_request("collect_17", 
		"URL=https://www.google-analytics.com/j/collect?v=1&_v=j101&a=1799622629&t=pageview&_s=1&dl=http%3A%2F%2Floadrunnertips.com%2FLoadRunner_Correlation_Challenge_Mod.aspx%3Fdd%3D1%26game%3DVolleyball&ul=en-gb&de=UTF-8&dt=LoadRunner%3A%20Correlation%20Challenge&sd=24-bit&sr=1280x720&vp=1263x593&je=0&_u=AACAAEABAAAAACAAI~&jid=&gjid=&cid=980661036.1708337501&tid=UA-54539864-2&_gid=1672187656.1708337501&_slc=1&z=2070918159", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://loadrunnertips.com/", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		LAST);

	lr_think_time(5);

	web_custom_request("collect_18", 
		"URL=https://www.google-analytics.com/g/collect?v=2&tid=G-7JE8RPG7Y7&gtm=45je42e0v9134516205za200&_p=1708337614689&gcd=13l3l3l3l2&npa=0&dma=0&ul=en-gb&sr=1280x720&cid=980661036.1708337501&are=1&pscdl=noapi&_eu=ABAI&_s=1&dl=http%3A%2F%2Floadrunnertips.com%2FLoadRunner_Correlation_Challenge_Mod.aspx%3Fdd%3D1%26game%3DVolleyball&dt=LoadRunner%3A%20Correlation%20Challenge&sid=1708337502&sct=1&seg=1&en=page_view&_ee=1&tfd=5790", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=http://loadrunnertips.com/", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	return 0;
}