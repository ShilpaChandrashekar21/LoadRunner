Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("loadrunnertips.com", 
		"URL=http://loadrunnertips.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_url("runner.html", 
		"URL=https://tpc.googlesyndication.com/sodar/sodar2/225/runner.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://loadrunnertips.com/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("__gads=ID=a8824a4b5768e0d8:T=1708336880:RT=1708336880:S=ALNI_MatfnOFzDie7TA6-Ik15uvH92azjg; DOMAIN=loadrunnertips.com");

	web_add_cookie("__gpi=UID=00000d0a3cab1aad:T=1708336880:RT=1708336880:S=ALNI_MYNHgOPKJksHT4M-3CW1WZiJ-aBjw; DOMAIN=loadrunnertips.com");

	web_add_cookie("__eoi=ID=77803d0e18aa3a57:T=1708336880:RT=1708336880:S=AA-AfjZAna6I0bMUcmK9TrPWsuNb; DOMAIN=loadrunnertips.com");

	lr_think_time(14);

	web_url("LoadRunner_Correlation_Challenge_Mod.aspx", 
		"URL=http://loadrunnertips.com/LoadRunner_Correlation_Challenge_Mod.aspx", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://loadrunnertips.com/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("NID=511=ePBqDEFmXD30FwakcmZcJ2POL7s0FngQBNb7DSMYQrNBUeY5VPKNEeAAl9alFR58GxCxfdpfSOmri8AmOwcHxpVY4Dmu9cTpECWZJtsXQTCpdsnkemUgwK-lOTHjFxkgt3XZ3H--Bib6lCWHGs1dA8oTTXnhaBIlGvPaOWt1BcQ; DOMAIN=safebrowsing.google.com");

	web_custom_request("crx-telemetry", 
		"URL=https://safebrowsing.google.com/safebrowsing/clientreport/crx-telemetry", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=application/octet-stream", 
		"BodyBinary=\\x08\\xDC\\x88\\xC1\\x86\\xDC1\\x12M\nK\n ahfgeienlihckogmohjhadlkjgocpleb\\x12\\x030.2\\x1A\tWeb Store \\xCC\\x88\\xB9\\xD4\\xE40(\\x000\\x008\\x00@\\x00H\\x00P\\x04X\\x05`\\x00h\\x00\\x12Z\nX\n ghbmnnjooekpmoecnnnilnnbdlolhkhi\\x12\\x061.73.0\\x1A\\x13Google Docs Offline \\x92\\x86\\xA9\\xD9\\xD11(\\x010\\x008\\x01@\\x01H\\x00P\\x01X\\x06`\\x00h\\x00\\x12r\np\n mbopgmdnpcbohhpnfglgohlbhfongabi\\x12\\x056.4.0\\x1A,BlazeMeter | The Continuous Testing Platform \\xAE\\xB1\\xC2\\xAD\\xDB1"
		"(\\x000\\x008\\x01@\\x01H\\x00P\\x01X\\x01`\\x00h\\x00\\x12S\nQ\n mhjfbmdgcfjbbpaeojofohoefgiehjai\\x12\\x011\\x1A\\x11Chrome PDF Viewer \\xCD\\x88\\xB9\\xD4\\xE40(\\x000\\x008\\x00@\\x00H\\x00P\\x01X\\x05`\\x00h\\x00\\x12Y\nW\n neajdppkdcdipfabeoofebfddakdcjhd\\x12\\x031.0\\x1A\\x15Google Network Speech \\xCE\\x88\\xB9\\xD4\\xE40(\\x000\\x008\\x00@\\x00H\\x00P\\x01X\\x05`\\x00h\\x00\\x12V\nT\n nkeimhogjdpnpccoofpliimaahmaaome\\x12\\x061.3.21\\x1A\\x0FGoogle Hangouts \\xCD\\x88\\xB9\\xD4\\xE40"
		"(\\x000\\x008\\x00@\\x00H\\x00P\\x01X\\x05`\\x00h\\x00\\x12a\n_\n nmmhkkegccagdldgiimedpiccmgmieda\\x12\\x071.0.0.6\\x1A\\x19Chrome Web Store Payments \\x85\\xA2\\xB9\\xD4\\xE40(\\x010\\x008\\x01@\\x01H\\x00P\\x06X\n`\\x00h\\x00", 
		LAST);

	web_custom_request("crx-telemetry_2", 
		"URL=https://safebrowsing.google.com/safebrowsing/clientreport/crx-telemetry", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=application/octet-stream", 
		"BodyBinary=\\x08\\xE5\\xD0\\xC1\\x85\\xDC1\\x12M\nK\n ahfgeienlihckogmohjhadlkjgocpleb\\x12\\x030.2\\x1A\tWeb Store \\xCC\\x88\\xB9\\xD4\\xE40(\\x000\\x008\\x00@\\x00H\\x00P\\x04X\\x05`\\x00h\\x00\\x12Z\nX\n ghbmnnjooekpmoecnnnilnnbdlolhkhi\\x12\\x061.73.0\\x1A\\x13Google Docs Offline \\x92\\x86\\xA9\\xD9\\xD11(\\x010\\x008\\x01@\\x01H\\x00P\\x01X\\x06`\\x00h\\x00\\x12r\np\n mbopgmdnpcbohhpnfglgohlbhfongabi\\x12\\x056.4.0\\x1A,BlazeMeter | The Continuous Testing Platform \\xAE\\xB1\\xC2\\xAD\\xDB1"
		"(\\x000\\x008\\x01@\\x01H\\x00P\\x01X\\x01`\\x00h\\x00\\x12S\nQ\n mhjfbmdgcfjbbpaeojofohoefgiehjai\\x12\\x011\\x1A\\x11Chrome PDF Viewer \\xCD\\x88\\xB9\\xD4\\xE40(\\x000\\x008\\x00@\\x00H\\x00P\\x01X\\x05`\\x00h\\x00\\x12Y\nW\n neajdppkdcdipfabeoofebfddakdcjhd\\x12\\x031.0\\x1A\\x15Google Network Speech \\xCE\\x88\\xB9\\xD4\\xE40(\\x000\\x008\\x00@\\x00H\\x00P\\x01X\\x05`\\x00h\\x00\\x12V\nT\n nkeimhogjdpnpccoofpliimaahmaaome\\x12\\x061.3.21\\x1A\\x0FGoogle Hangouts \\xCD\\x88\\xB9\\xD4\\xE40"
		"(\\x000\\x008\\x00@\\x00H\\x00P\\x01X\\x05`\\x00h\\x00\\x12a\n_\n nmmhkkegccagdldgiimedpiccmgmieda\\x12\\x071.0.0.6\\x1A\\x19Chrome Web Store Payments \\x85\\xA2\\xB9\\xD4\\xE40(\\x010\\x008\\x01@\\x01H\\x00P\\x06X\n`\\x00h\\x00", 
		LAST);

	web_custom_request("command", 
		"URL=https://clients4.google.com/chrome-sync/command/?client=Google+Chrome&client_id=EqBJmtXuwdBaPOmd8C%2FKQg%3D%3D", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/vnd.google.octet-stream-compressible", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/octet-stream", 
		"BodyBinary=\n\\x18shilpagowda939@gmail.com\\x10c\\x18\\x02*'\\x12\\x04\\x08\\x00\\x10\\x00\\x18\\x012\\x04\\x08\\xDE\\xD8\\x122\\x13\\x08\\x81\\xF5\\x02\\x12\r \\x00\\x88\\x01\\xAF\\xC8\\xC9\\xCB\\xC4\\x9F\\xD4\\xB4\\x01@\\x00H\\x07:%z00000162-c454-d76e-0000-00005ad2013dR\\x12\n\\x02\\x08\\x05\n\\x02\\x08\t\n\\x02\\x08\n\\x10\\x01\\x18\\x00 \\x00Z\\x81\\x01\n\\x7F\\x12}Chrome WIN 121.0.6167.185 (057a8ae7deb3374d0f1b04b36304d236f0136188-refs/branch-heads/6167@{#1818}) channel(stable),gzip(gfe)"
		"b'AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgwj\\x02\\x10\\x00", 
		LAST);

	/* start */

	lr_think_time(8);

	web_submit_data("LoadRunner_Correlation_Challenge_Mod.aspx_2", 
		"Action=http://loadrunnertips.com/LoadRunner_Correlation_Challenge_Mod.aspx", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://loadrunnertips.com/LoadRunner_Correlation_Challenge_Mod.aspx", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__VIEWSTATE", "Value=/wEPDwUJOTg3MDg5NjY4ZGSpeujMXq9dhhW/s7hcdKBqtNppWxSDRQiCpjYtl/zM8Q==", ENDITEM, 
		"Name=__VIEWSTATEGENERATOR", "Value=3074961D", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value=/wEdAAI8SKNQprDFK8rsi0EJ5/yGnlbekVM3R/a0oKRYPLuOREujrpNMsu4xbEP1zwz+bV66MXj1n2GeMVkJ2V0pBksg", ENDITEM, 
		"Name=ctl00$head$btnStart", "Value=Start", ENDITEM, 
		LAST);

	web_custom_request("WXWI6A7IBNOHMBWFQDDLSBEJM25AKK7U5BVHF3P4IL2JWJGHHJICHPUEDL2VSWNHRAPOLCUM4Q2D6736L5MRCCVL3VM5XYPPBZSOXM7SJKS2MAILCSZZXYAMRHCEVZSLVEDSHTAXHMBOCBAIX56NNXVTSZ6HOVWAHYFITV5I5U3JAXEES3NHL7RQVIU3KBZR4QJPBZEHLCM7MM6OEKBXKLEIA5KEW3FLJ4TLDPSJOMNRHILNDT3EIM55J7TTKBJW", 
		"URL=https://b1t-sindc1.zemanta.com/t/imp/view/WXWI6A7IBNOHMBWFQDDLSBEJM25AKK7U5BVHF3P4IL2JWJGHHJICHPUEDL2VSWNHRAPOLCUM4Q2D6736L5MRCCVL3VM5XYPPBZSOXM7SJKS2MAILCSZZXYAMRHCEVZSLVEDSHTAXHMBOCBAIX56NNXVTSZ6HOVWAHYFITV5I5U3JAXEES3NHL7RQVIU3KBZR4QJPBZEHLCM7MM6OEKBXKLEIA5KEW3FLJ4TLDPSJOMNRHILNDT3EIM55J7TTKBJWSAQQGQFXG3V2RN5MJP43IO5TVAWUDNVKKRWOXBPOIQWTOUPWQEYQUUSYG66VEQN7VG7UZZUZZZ74V66WPNGJE6GFTNUB5BKW55XIKRQ/?", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=https://googleads.g.doubleclick.net/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_custom_request("2QFQCM22ST4FN4KM744WFXU35S5AKK7U5BVHF3IHUFNLOSJ2VV74KOPRZM6SVWBC3RFRJAEIA2WZXIBN7T4I4KN56HNRKMQ5JWQCHQLFDRNIEBWA6SURGPQEPAPFP7MRFSLOFNECT552MBAIX56NNXVTSZ6HOVWAHYFITV5I5U3JAXEES3NCE6NTBABED4KD4QJPBZEHLCM7MM6OEKBXKLEIA6BOO3MGCUTCZJ2JOMNRHILNDT3EJ5AJNLGJULYD", 
		"URL=https://b1t-sindc1.zemanta.com/t/imp/view/2QFQCM22ST4FN4KM744WFXU35S5AKK7U5BVHF3IHUFNLOSJ2VV74KOPRZM6SVWBC3RFRJAEIA2WZXIBN7T4I4KN56HNRKMQ5JWQCHQLFDRNIEBWA6SURGPQEPAPFP7MRFSLOFNECT552MBAIX56NNXVTSZ6HOVWAHYFITV5I5U3JAXEES3NCE6NTBABED4KD4QJPBZEHLCM7MM6OEKBXKLEIA6BOO3MGCUTCZJ2JOMNRHILNDT3EJ5AJNLGJULYDSAQQGQFXG3V2RN5MJP43IO5TVAWUDNVKKRWOXBORHCJSH2DSKOIAUUSYG66VEQN7VG7UZZUZZZ74V66WPNGJE6GFTNUB5BKW55XIKRQ/?", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=https://googleads.g.doubleclick.net/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("2QFQCM22ST4FMRVSRPBPX5DSUG5AKK7U5BVHF3JAZYU4CH7BKF35VWCXSLTTTMASBHSASOGLV2F7WBX2IR5KKI7F7OWQLPR6Q6QQAYKV2TX2RSSO6NEITJLYJOUCVU53NFGEK6OG47NT2BAIX56NNXVTSZ6HOVWAHYFITV5I5U3JAXEES3NCE6NTBABED4KD4QJPBZEHLCM7MM6OEKBXKLEIA6BOO3MGCUTCZJ2JOMNRHILNDT3EJ5AJNLGJULYD", 
		"URL=https://b1t-sindc1.zemanta.com/t/imp/view/2QFQCM22ST4FMRVSRPBPX5DSUG5AKK7U5BVHF3JAZYU4CH7BKF35VWCXSLTTTMASBHSASOGLV2F7WBX2IR5KKI7F7OWQLPR6Q6QQAYKV2TX2RSSO6NEITJLYJOUCVU53NFGEK6OG47NT2BAIX56NNXVTSZ6HOVWAHYFITV5I5U3JAXEES3NCE6NTBABED4KD4QJPBZEHLCM7MM6OEKBXKLEIA6BOO3MGCUTCZJ2JOMNRHILNDT3EJ5AJNLGJULYDSAQQGQFXG3V2RN5MJP43IO5TVAWUDNVKKRWOXBORHCJSH2DSKOIAUUSYG66VEQN7VG7UZZUZZZ74V66WPNGJE6GFTNUB5BKW55XIKRQ/?", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=https://googleads.g.doubleclick.net/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	/* number */

	lr_think_time(14);

	web_submit_data("LoadRunner_Correlation_Challenge_Mod.aspx_3", 
		"Action=http://loadrunnertips.com/LoadRunner_Correlation_Challenge_Mod.aspx", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://loadrunnertips.com/LoadRunner_Correlation_Challenge_Mod.aspx", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__VIEWSTATE", "Value=/wEPDwUJOTg3MDg5NjY4ZGSpeujMXq9dhhW/s7hcdKBqtNppWxSDRQiCpjYtl/zM8Q==", ENDITEM, 
		"Name=__VIEWSTATEGENERATOR", "Value=3074961D", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value=/wEdAAM8SKNQprDFK8rsi0EJ5/yGEZwAPPXs+fTr6SGYYqMh2jrXPBqUZcs4yqSWpp6/FIQD1Rc0mWY9uuZuEzjglRSMxfhFsuoZ/uWxprC3MuRsOg==", ENDITEM, 
		"Name=ctl00$head$txtMacigNo", "Value=8674", ENDITEM, 
		"Name=ctl00$head$btnNext", "Value=Next", ENDITEM, 
		LAST);

	/* default value */

	return 0;
}