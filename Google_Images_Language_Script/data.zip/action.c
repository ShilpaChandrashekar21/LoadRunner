Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("rs=AA2YrTungzasoekTaLKrPFUaQFpakqDmnA", 
		"URL=https://www.gstatic.com/og/_/ss/k=og.qtm.8RUPaHb7e5o.L.W.O/m=qcwid/excm=qaaw,qadd,qaid,qein,qhaw,qhba,qhbr,qhch,qhga,qhid,qhin/d=1/ed=1/ct=zgms/rs=AA2YrTungzasoekTaLKrPFUaQFpakqDmnA", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://www.google.com/", 
		"Snapshot=t1.inf", 
		LAST);

	web_url("rs=AA2YrTvRRKYp7I5vTn-AtFvme6Qlo6hq9Q", 
		"URL=https://www.gstatic.com/og/_/js/k=og.qtm.en_US.ZEEp2pdSHOQ.2019.O/rt=j/m=qabr,q_d,qcwid,qapid,qald,q_dg/exm=qaaw,qadd,qaid,qein,qhaw,qhba,qhbr,qhch,qhga,qhid,qhin/d=1/ed=1/rs=AA2YrTvRRKYp7I5vTn-AtFvme6Qlo6hq9Q", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://www.google.com/", 
		"Snapshot=t2.inf", 
		LAST);

	web_add_cookie("ACCOUNT_CHOOSER=AFx_qI7txxtaQPd_CINSxpVGU9Wh0qq-lorGwZsCNhOXEXN7MDvFyfNuCXjlLnmi4nx96cMDiUsbDJQLB6i9ThuqE0Ms_ZwlQ1__s0ax1UEf1MLUaACZzecLTo_rjoaw2kQB5MoWQXM-XfZJ_XLc8_INAVdgTp67Ew; DOMAIN=accounts.google.com");

	web_add_cookie("OTZ=7377528_34_34__34_; DOMAIN=accounts.google.com");

	web_add_cookie("SID=fQiibRM-AyQK3aepIXh9z7m-EL02K6vCoureg_69byHgoKqPDiDF0Qu_QkWWLMy0U8kC3w.; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PSID=fQiibRM-AyQK3aepIXh9z7m-EL02K6vCoureg_69byHgoKqPkRshzyvjQS8Dyx8v1K6COg.; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PSID=fQiibRM-AyQK3aepIXh9z7m-EL02K6vCoureg_69byHgoKqPi7rEB6c1q9ywMdWbf9wvgA.; DOMAIN=accounts.google.com");

	web_add_cookie("HSID=A_7sCt_SLQq6NJJqu; DOMAIN=accounts.google.com");

	web_add_cookie("SSID=Avo3qPYeN4nmd99NJ; DOMAIN=accounts.google.com");

	web_add_cookie("APISID=J2OUGWcYl7CqVvkA/Al3xXwEagQ2f0owc6; DOMAIN=accounts.google.com");

	web_add_cookie("SAPISID=aGcHjmEmumsr15JN/At6jfud9wCnQlB2L8; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PAPISID=aGcHjmEmumsr15JN/At6jfud9wCnQlB2L8; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PAPISID=aGcHjmEmumsr15JN/At6jfud9wCnQlB2L8; DOMAIN=accounts.google.com");

	web_add_cookie("SEARCH_SAMESITE=CgQIqJoB; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-GAPS=1:G-3xh9AwoPKKxpLxVowC7F7g42p-wTXcUZk7oPqn2eXti2P1x6zBpxy8KXhVBv5lGHEeeGZp9ElA-4u6lUJiF_IiuoC15w:_yoY8hxmYL_UNRxs; DOMAIN=accounts.google.com");

	web_add_cookie("LSID=o.chat.google.com|o.chromewebstore.google.com|o.drive.google.com|o.gds.google.com|o.mail.google.com|o.meet.google.com|o.photos.fife.usercontent.google.com|o.photos.google.com|s.IN:fQiibdzTtpGQdDd990_QaXfPVAm1G-QaIo2N2RcgRfMzSBx0tOODs6_eVZvLvIIUrG9Pcw.; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-1PLSID=o.chat.google.com|o.chromewebstore.google.com|o.drive.google.com|o.gds.google.com|o.mail.google.com|o.meet.google.com|o.photos.fife.usercontent.google.com|o.photos.google.com|s.IN:fQiibdzTtpGQdDd990_QaXfPVAm1G-QaIo2N2RcgRfMzSBx0RnZwpj2XEzByxVVQAsR2Yw.; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-3PLSID=o.chat.google.com|o.chromewebstore.google.com|o.drive.google.com|o.gds.google.com|o.mail.google.com|o.meet.google.com|o.photos.fife.usercontent.google.com|o.photos.google.com|s.IN:fQiibdzTtpGQdDd990_QaXfPVAm1G-QaIo2N2RcgRfMzSBx08rhNG4Wo6HcxpJE8oG5NAg.; DOMAIN=accounts.google.com");

	web_add_cookie("AEC=Ae3NU9OrnD5tBVLwGGp1gPS_B1Uuw4m6nJ8W7r1n606gKmlcOg_4SYtPe7I; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PSIDTS=sidts-CjIBPVxjSnx6bLmME0ZecNk8B6BxgROwXZEFqdo4DQET-TZ_4Dtl-ETYUqJ2He8cVyHZ3hAA; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PSIDTS=sidts-CjIBPVxjSnx6bLmME0ZecNk8B6BxgROwXZEFqdo4DQET-TZ_4Dtl-ETYUqJ2He8cVyHZ3hAA; DOMAIN=accounts.google.com");

	web_add_cookie("1P_JAR=2024-02-05-09; DOMAIN=accounts.google.com");

	web_add_cookie("NID=511=W0e7rCeOTGbkMncSyNV-qReety-hAuvLWzk0nirfDbtQC51PeRmCNf5SxiQOgUx-4xgyxhxPb0kb9SqZfhzDtoeYMckyR-ovFt1ynuYCcA2hJ7r_Eyyasi-MT9-9lreRxEabYpp7HXurdI4S2zKMCjpzwDZV1BapDDX7feC_XzFCztjaN4ECW5QHpl5QpLjs9txQJR81TuEzmFo6j0QtLX1g5nVUjvkniwAaA79agtjZV0rhwTD3bHE5ubfR_og7CRpMFDCFVo_X-xRsXtq3DqspGP2Fw5vhPwCyx35NbRWaX1X-nqCuptezJChbdL3s; DOMAIN=accounts.google.com");

	web_add_cookie("SIDCC=ABTWhQGt6Utt8xQrzlWYNu7GKi7cONK74xQPMR15fi7x-0P22px6XUIVMz6S6Aa97VbMPMCRJw; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PSIDCC=ABTWhQE5GmbdEwmT9j7_dXdu_xrC5iSgys-R0-dAsP1psQN_eEX94dGYfDGBNWwX-ivIcV2PHAU; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PSIDCC=ABTWhQFfySX21Q9WPY617belK66lD54fftDtyM17vXZt8L_OoqcvtyMcewNIPrSKlfWUG24FSkM; DOMAIN=accounts.google.com");

	web_custom_request("ListAccounts", 
		"URL=https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"Body= ", 
		EXTRARES, 
		"Url=https://content-autofill.googleapis.com/v1/pages/ChVDaHJvbWUvMTIxLjAuNjE2Ny4xNDASGQn11VQ7sgCk8RIFDWlIR0chrbMLunyG1js=?alt=proto", "Referer=", ENDITEM, 
		LAST);

	web_add_cookie("1P_JAR=2024-02-06-07; DOMAIN=ogs.google.com");

	web_add_cookie("AEC=Ae3NU9NbMCfbdDBowgga45Ht4pWIV740Y_i2q8KKeyYcnjNrkmlVOSMFcg; DOMAIN=ogs.google.com");

	web_add_cookie("NID=511=uJbyQkgH7OpFcnfAcKxxx5EWLPh4u64z24ht_S7i1-rLxIPKrjOownbl7z8z2Ss0ZHfoB7_TrcypZ-pym7uIeQdYk55kU6jadsT_EuZrTENP1DRqtslfCmcP-7GDz_wH8cNtFulKfSP8uPrNYnJgWVgzi1IxZD2iQO87qbZRwQA; DOMAIN=ogs.google.com");

	web_add_cookie("1P_JAR=2024-02-06-07; DOMAIN=apis.google.com");

	web_add_cookie("AEC=Ae3NU9NbMCfbdDBowgga45Ht4pWIV740Y_i2q8KKeyYcnjNrkmlVOSMFcg; DOMAIN=apis.google.com");

	web_add_cookie("NID=511=uJbyQkgH7OpFcnfAcKxxx5EWLPh4u64z24ht_S7i1-rLxIPKrjOownbl7z8z2Ss0ZHfoB7_TrcypZ-pym7uIeQdYk55kU6jadsT_EuZrTENP1DRqtslfCmcP-7GDz_wH8cNtFulKfSP8uPrNYnJgWVgzi1IxZD2iQO87qbZRwQA; DOMAIN=apis.google.com");

	web_url("callout", 
		"URL=https://ogs.google.com/widget/callout?prid=19037050&pgid=19037049&puid=a5627eb5c02923db&cce=1&dc=1&origin=https%3A%2F%2Fwww.google.com&cn=callout&pid=1&spid=538&hl=en", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.google.com/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://apis.google.com/_/scs/abc-static/_/js/k=gapi.gapi.en.GsbA68hXs80.O/m=gapi_iframes,googleapis_client/rt=j/sv=1/d=1/ed=1/rs=AHpOoo899t-H8Lxb3OqzMDuPn6TV_i36ag/cb=gapi.loaded_0", "Referer=https://www.google.com/", ENDITEM, 
		"Url=https://fonts.gstatic.com/s/googlesans/v58/4Ua_rENHsxJlGDuGo1OIlJfC6l_24rlCK1Yo_Iqcsih3SAyH6cAwhX9RFD48TE63OOYKtrw2IJllpyk.woff2", "Referer=https://ogs.google.com/", ENDITEM, 
		"Url=https://fonts.gstatic.com/s/roboto/v18/KFOmCnqEu92Fr1Mu4mxK.woff2", "Referer=https://ogs.google.com/", ENDITEM, 
		LAST);

	web_custom_request("log", 
		"URL=https://play.google.com/log?format=json&hasfast=true&authuser=0", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://ogs.google.com/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_add_cookie("1P_JAR=2024-02-06-07; DOMAIN=play.google.com");

	web_add_cookie("AEC=Ae3NU9NbMCfbdDBowgga45Ht4pWIV740Y_i2q8KKeyYcnjNrkmlVOSMFcg; DOMAIN=play.google.com");

	web_add_cookie("NID=511=WRlCrztThapX0sshPa4NIE-ZOB33Wuviu__00ZYXI8C4_SqIU4XE5XHl_nHf1gW_qppJSvQlYIUCa89wWfvYoAEG_GZge0tCQBrMAKtIO7GpHMtAsgMw0LJ5aYeXpVk3ztuIvGA4vBBT2yEzQeLRdsupJHNqS9kyMr8I0QRFE3UXfmcnh1Ido0M; DOMAIN=play.google.com");

	web_add_cookie("OGPC=19037049-1:; DOMAIN=play.google.com");

	web_custom_request("log_2", 
		"URL=https://play.google.com/log?format=json&hasfast=true", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=https://www.google.com/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded;charset=UTF-8", 
		"Body=[[1,null,null,null,null,null,null,null,null,null,[null,null,null,null,\"en-IN\",null,null,null,[[[\"Not A(Brand\",\"99\"],[\"Google Chrome\",\"121\"],[\"Chromium\",\"121\"]],0,\"Windows\",\"10.0.0\",\"x86\",\"\",\"121.0.6167.140\"],[1,0,0,0,0]]],373,[[\"1707203141617\",null,null,null,null,null,null,\"[108,40400,538,1,\\\"602241693.0\\\",\\\"RNrBZZOENoHCg8UPr966YA\\\",null,null,null,\\\"en\\\",\\\"IND\\\",0,8,2044,null,0,0,null,\\\"og-8b37c63d-75ab-486f-a4f2-f0443b4da9bd\\\",null,null,null,"
		"null,null,null,null,0,null,null,null,19037050,null,null,null,null,0,[1],1,null,null,null,null,null,null,null,null,null,null,null,[0,2],null,null,null,null,0,null,[2,5,\\\"sl\\\",15],null,null,0,0,1]\",null,null,null,null,null,null,-19800,[null,null,null,\"[null,null,[3700949]]\"],null,null,null,null,1],[\"1707203141621\",null,null,null,null,null,null,\"[107,40400,538,1,\\\"602241693.0\\\",\\\"RNrBZZOENoHCg8UPr966YA\\\",null,null,null,\\\"en\\\",\\\"IND\\\",0,8,2048,null,0,0,null,\\\""
		"og-8b37c63d-75ab-486f-a4f2-f0443b4da9bd\\\",null,null,null,null,null,null,null,8,null,null,null,19037050,null,null,null,null,0,[2],2,null,null,null,null,null,null,null,null,null,null,null,[0,2],null,null,null,null,0,null,[2,5,\\\"sl\\\",15],null,null,0,0,1]\",null,null,null,null,null,null,-19800,[null,null,null,\"[null,null,[3700949]]\"],null,null,null,null,2],[\"1707203142083\",null,null,null,null,null,null,\"[109,40400,538,1,\\\"602241693.0\\\",\\\"RNrBZZOENoHCg8UPr966YA\\\",null,null,null,\\\""
		"en\\\",\\\"IND\\\",0,8,2510,null,0,0,null,\\\"og-8b37c63d-75ab-486f-a4f2-f0443b4da9bd\\\",null,null,null,null,null,null,null,32936,null,null,null,19037050,null,null,null,null,0,[3],3,null,null,null,null,null,null,null,null,null,null,null,[0,2],null,null,null,null,0,null,[2,5,\\\"sl\\\",15],null,null,0,0,1]\",null,null,null,null,null,null,-19800,[null,null,null,\"[null,null,[3700949]]\"],null,null,null,null,3],[\"1707203142090\",null,null,null,null,null,null,\"[36,40400,538,1,\\\"602241693.0\\\","
		"\\\"RNrBZZOENoHCg8UPr966YA\\\",null,null,null,\\\"en\\\",\\\"IND\\\",0,8,2517,null,0,0,null,\\\"og-8b37c63d-75ab-486f-a4f2-f0443b4da9bd\\\",null,null,null,null,473,null,null,32938,null,null,null,19037050,null,null,null,null,null,null,4,-1,null,null,null,76,256,879,1249,null,null,null,[0,2,1,0,0],null,null,null,null,0,null,[2,5,\\\"sl\\\",15],null,null,0,0,1]\",null,null,null,null,null,null,-19800,[null,null,null,\"[null,null,[3700949]]\"],null,null,null,null,4]],\"1707203142619\",null,null,null,"
		"null,null,null,null,null,null,null,null,null,null,[[null,[null,null,null,null,null,null,null,null,null,null,null,null,122505695]],9]]", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	lr_think_time(7);

	web_custom_request("command", 
		"URL=https://clients4.google.com/chrome-sync/command/?client=Google+Chrome&client_id=EqBJmtXuwdBaPOmd8C%2FKQg%3D%3D", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/vnd.google.octet-stream-compressible", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/octet-stream", 
		"BodyBinary=\n\\x18shilpagowda939@gmail.com\\x10c\\x18\\x02*'\\x12\\x04\\x08\\x00\\x10\\x00\\x18\\x012\\x04\\x08\\xDE\\xD8\\x122\\x13\\x08\\x81\\xF5\\x02\\x12\r \\x00\\x88\\x01\\xAF\\xC8\\xC9\\xCB\\xC4\\x9F\\xD4\\xB4\\x01@\\x00H\\x07:%z00000162-c454-d76e-0000-00005ad2013dR\\x12\n\\x02\\x08\\x05\n\\x02\\x08\t\n\\x02\\x08\n\\x10\\x01\\x18\\x00 \\x00Z\\x81\\x01\n\\x7F\\x12}Chrome WIN 121.0.6167.140 (a5856993c61543d4acbee5f848f1750607e87ba0-refs/branch-heads/6167@{#1684}) channel(stable),gzip(gfe)"
		"b'AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgwj\\x02\\x10\\x00", 
		LAST);

	lr_think_time(48);

	web_custom_request("json", 
		"URL=http://update.googleapis.com/service/update2/json?cup2key=13:Za8QcjXI_5r8bvhuJjeVo-gKN7ItlMioehxmdJz-wJQ&cup2hreq=1c274d667ebf44a74c46e7539104bd25f9210fa7706858f58b7d6692110c8394", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.30f5f886b824ca1efde5174370fc03cab3c02e9c309bc381857430f5843a510b\"}]},\"ping\":{\"ping_freshness\":\"{45b199ec-bc45-4154-b804-17bed3e9a385}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"1.3.36.311\"},{\"appid\":\""
		"neifaoindggfcjicffkgpmnlppeffabd\",\"brand\":\"GGLS\",\"cohort\":\"1:1299:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.c900ba9a2d8318263fd43782ee6fd5fb50bad78bf0eb2c972b5922c458af45ed\"}]},\"ping\":{\"ping_freshness\":\"{fa61cb21-e2a5-469a-b851-c5ba0d9e473f}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"1.0.2738.0\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"GGLS\",\"cohort\":\"1:bm1:\",\"cohortname\""
		":\"Stable\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.cd1978742a4afdbaaa15bf712d5c90bef4144caa99024df98f6a9ad58043ae85\"}]},\"ping\":{\"ping_freshness\":\"{1bb58770-b04f-4108-8931-944d4bed170a}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"9.49.1\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"GGLS\",\"cohort\":\"1:1zdx:\",\"cohortname\":\"Chrome 106+\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"ping\":{\""
		"ping_freshness\":\"{02dff918-1205-4043-a71d-c78849550114}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"4.10.2710.0\"},{\"accept_locale\":\"ENGB500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"GGLS\",\"cohort\":\"1:s6f/20ol:20or@0.5\",\"cohortname\":\"Rollout\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.8069f8805123f74944304604381770bb694317c9e1044e096f540222dc56c0f6\"}]},\"ping\":{\"ping_freshness\":\""
		"{99192b7a-884e-460d-a1fc-e3c7642d2f63}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"20230923.567854667.14\"},{\"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"GGLS\",\"cohort\":\"1:lwl:27p3@0.025\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.cadbf9a5f27721576d77d35576f37ca01ac34d86bce73958bf71cde62af71b48\"}]},\"ping\":{\"ping_freshness\":\"{d0defa40-bae0-4603-83dc-713352dceaa0}\",\"rd\":6244},\"updatecheck\":"
		"{},\"version\":\"432\"},{\"appid\":\"kiabhabjdbkjdpjbpigfodbdjmbglcoo\",\"brand\":\"GGLS\",\"cohort\":\"1:v3l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6134,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.4a6508925b2ffec931c1e3931ddeb15ca41d820a8264cd5a962b526e9932bcdf\"}]},\"ping\":{\"ping_freshness\":\"{b021282d-6070-4a78-9193-2e3b8bda55ef}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"2024.1.2.1\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"GGLS\","
		"\"cohort\":\"1:cux:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.f4f1eb04881095d1cc8f2e1799a8144c10476dc1088a03ecdb4418644040a554\"}]},\"ping\":{\"ping_freshness\":\"{4577b234-53e9-45b6-893b-cdfa98bde81c}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"63\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\""
		"package\":[{\"fp\":\"1.3a118962ef814c91f6476bb9f0de58afa63103af6ac1b8729be9b39a86789e96\"}]},\"ping\":{\"ping_freshness\":\"{24d58d31-e5b2-4d83-9308-b85cb212f735}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"1.0.0.15\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GGLS\",\"cohort\":\"1:jcl:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.90f54a8ca8c3135f647fedbb5f38ecadbbae4d45dafc3b73cde0c96d924a1773\"}]},"
		"\"ping\":{\"ping_freshness\":\"{119058c8-6e7e-4a34-8ddc-20949d5b4658}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"8531\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\":\"GGLS\",\"cohort\":\"1:10zr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{4d6cbdf7-fe46-4b7a-9368-01e3962f8a17}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"1.0.7.1652906823\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"GGLS\","
		"\"cohort\":\"1:ofl:\",\"cohortname\":\"stable64\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{b3c282f0-c3a7-4d98-a1f1-5a3add55a1d2}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\",\"brand\":\"GGLS\",\"cohort\":\"1:18ql:\",\"cohortname\":\"Auto Stage3\",\"enabled\":true,\"installdate\""
		":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.e4bdca96fb46d22bc12f5bc5bdb5cdb518555fd1762653f8afc96d06b34ec74b\"}]},\"ping\":{\"ping_freshness\":\"{0016f5f9-8df9-46ff-a401-c3ddc1d94880}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"852\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"GGLS\",\"cohort\":\"1:s7x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\""
		"1.887c873b6c3a26844482754c8534268fcd848b8c543b652626b4d4ec367f26fd\"}]},\"ping\":{\"ping_freshness\":\"{8a8ab3ca-8f61-4094-903c-9e1faf026df5}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"3017\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"GGLS\",\"cohort\":\"1:wvr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.c52c62a7c50daf7d3f73ec16977cd4b0ea401710807d5dbe3850941dd1b73a70\"}]},\"ping\":{\""
		"ping_freshness\":\"{c966c736-64dc-429e-8455-2edbcd138011}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"120.0.6050.0\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"GGLS\",\"cohort\":\"1:ut9/1a0f:23ml@0.1\",\"cohortname\":\"M108 and Above\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.c45cd56a0a8da0883c8f9757b31891d6c628f38cb80724015ffdf33b419a73f3\"}]},\"ping\":{\"ping_freshness\":\"{261398c3-ee74-4ba0-a78a-85a4669991ef}\",\"rd\""
		":6244},\"updatecheck\":{},\"version\":\"2023.11.27.1202\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"GGLS\",\"cohort\":\"1:w0x:\",\"cohortname\":\"All users\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.545666a4efd056351597bb386aea1368105ededc976ed5650d8682daab9f37ff\"}]},\"ping\":{\"ping_freshness\":\"{c435433c-ac8c-4702-8ab5-498f71387e2f}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"3\"},{\"appid\":\""
		"jflhchccmppkfebkiaminageehmchikm\",\"brand\":\"GGLS\",\"cohort\":\"1:26yf:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6148,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.74316953175dd4fc990c661551ce1387c462d705f9eff88d759fb130885a3530\"}]},\"ping\":{\"ping_freshness\":\"{fab4efa9-8495-4794-9ef4-55c47488beed}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"2024.2.4.1\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"GGLS\",\"cohort\":\"1:j5l:\",\""
		"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.fd515ec0dc30d25a09641b8b83729234bc50f4511e35ce17d24fd996252eaace\"}]},\"ping\":{\"ping_freshness\":\"{22a290ba-2819-41ac-981a-d251c7dcf2ad}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"GGLS\",\"cohort\":\"1:w59:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\""
		"package\":[{\"fp\":\"1.c64c9c1008f3ba5f6e18b3ca524bc98dcd8acfae0a2720a8f1f3ef0f8d643d05\"}]},\"ping\":{\"ping_freshness\":\"{57978dac-b1d6-42d5-b9af-13745d672b89}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"2020.11.2.164946\"},{\"appid\":\"gonpemdgkjcecdgbnaabipppbmgfggbe\",\"brand\":\"GGLS\",\"cohort\":\"1:z1x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5887,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\""
		"1.48fecfa3c6f59eb6c34fdd5e8f19e0678699e2f27dc8ebfa7025c246d4575c68\"}]},\"ping\":{\"ping_freshness\":\"{56043ec5-03d5-4a2e-bd05-d7e55e0004ab}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"2024.1.17.0\"},{\"appid\":\"niikhdgajlphfehepabhhblakbdgeefj\",\"brand\":\"GGLS\",\"cohort\":\"1:1uh3:\",\"cohortname\":\"Auto Main Cohort.\",\"enabled\":true,\"installdate\":6134,\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"1.31fc707db886cd7b31724279d1ce873be7f1ef84f9c8b0cb0664743d47e41217\"}]},\""
		"ping\":{\"ping_freshness\":\"{7b07ff1d-5018-414e-bb03-404cd62701b2}\",\"rd\":6244},\"updatecheck\":{},\"version\":\"2024.2.5.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":12,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.19045.3324\"},\"prodversion\":\"121.0.6167.140\",\"protocol\":\"3.1\",\""
		"requestid\":\"{5e90520e-02fe-4c86-98d7-be13bdaedddb}\",\"sessionid\":\"{035bc295-6713-4229-96af-2559ef83c31c}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"laststarted\":0,\"name\":\"ChromiumUpdater\",\"updatepolicy\":-1,\"version\":\"123.0.6268.0\"},\"updaterversion\":\"121.0.6167.140\"}}", 
		EXTRARES, 
		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates:fetch?$req="
		"Ch4KDGdvb2dsZWNocm9tZRIOMTIxLjAuNjE2Ny4xNDAaKQgFEAEaGwoNCAUQBhgBIgMwMDEwARCOlRUaAhgLCeMCWiIEIAEgAigBGikIARABGhsKDQgBEAYYASIDMDAxMAEQsukNGgIYC73ZJaEiBCABIAIoARopCAMQARobCg0IAxAGGAEiAzAwMTABEOvgDRoCGAuISvtoIgQgASACKAEaKQgOEAEaGwoNCA4QBhgBIgMwMDEwARC0rwcaAhgL_VjDViIEIAEgAigBGigIARAIGhoKDQgBEAgYASIDMDAxMAQQ3DcaAhgLwLZjkiIEIAEgAigEGikIDxABGhsKDQgPEAYYASIDMDAxMAEQ8qsCGgIYC3WkQCkiBCABIAIoARonCAoQCBoZCg0IChAIGAEiAzAwMTABEAcaAhgLYjna-CIEIAEgAigBGicICRABGhkKDQgJEAYYASIDMDAxMAEQIxoCGAuXnkjLIgQgASACKAEaKAgIEA"
		"EaGgoNCAgQBhgBIgMwMDEwARCwFRoCGAteoQ6BIgQgASACKAEaKQgNEAEaGwoNCA0QBhgBIgMwMDEwARCGjQIaAhgLVXGC1iIEIAEgAigBGikIBxABGhsKDQgHEAYYASIDMDAxMAEQ6a8OGgIYC1QeDNwiBCABIAIoARooCBAQARoaCg0IEBAGGAEiAzAwMTABEIshGgIYC7kwzGAiBCABIAIoASICCAE=&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", "Referer=", ENDITEM, 
		"Url=http://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=121", "Referer=", ENDITEM, 
		LAST);

	/* Click on Image Link */

	/* Back button */

	/* Click on Hindi Language link */

	/* Changing to english */

	return 0;
}