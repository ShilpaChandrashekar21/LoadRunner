Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("ACCOUNT_CHOOSER=AFx_qI7txxtaQPd_CINSxpVGU9Wh0qq-lorGwZsCNhOXEXN7MDvFyfNuCXjlLnmi4nx96cMDiUsbDJQLB6i9ThuqE0Ms_ZwlQ1__s0ax1UEf1MLUaACZzecLTo_rjoaw2kQB5MoWQXM-XfZJ_XLc8_INAVdgTp67Ew; DOMAIN=accounts.google.com");

	web_add_cookie("OTZ=7377528_34_34__34_; DOMAIN=accounts.google.com");

	web_add_cookie("SID=fQiibRM-AyQK3aepIXh9z7m-EL02K6vCoureg_69byHgoKqPDiDF0Qu_QkWWLMy0U8kC3w.; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PSID=fQiibRM-AyQK3aepIXh9z7m-EL02K6vCoureg_69byHgoKqPkRshzyvjQS8Dyx8v1K6COg.; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PSID=fQiibRM-AyQK3aepIXh9z7m-EL02K6vCoureg_69byHgoKqPi7rEB6c1q9ywMdWbf9wvgA.; DOMAIN=accounts.google.com");

	web_add_cookie("HSID=A_7sCt_SLQq6NJJqu; DOMAIN=accounts.google.com");

	web_add_cookie("SSID=Avo3qPYeN4nmd99NJ; DOMAIN=accounts.google.com");

	web_add_cookie("APISID=J2OUGWcYl7CqVvkA/Al3xXwEagQ2f0owc6; DOMAIN=accounts.google.com");

	web_add_cookie("SAPISID=aGcHjmEmumsr15JN/At6jfud9wCnQlB2L8; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PAPISID=aGcHjmEmumsr15JN/At6jfud9wCnQlB2L8; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PAPISID=aGcHjmEmumsr15JN/At6jfud9wCnQlB2L8; DOMAIN=accounts.google.com");

	web_add_cookie("SEARCH_SAMESITE=CgQIqJoB; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-GAPS=1:G-3xh9AwoPKKxpLxVowC7F7g42p-wTXcUZk7oPqn2eXti2P1x6zBpxy8KXhVBv5lGHEeeGZp9ElA-4u6lUJiF_IiuoC15w:_yoY8hxmYL_UNRxs; DOMAIN=accounts.google.com");

	web_add_cookie("LSID=o.chat.google.com|o.chromewebstore.google.com|o.drive.google.com|o.gds.google.com|o.mail.google.com|o.meet.google.com|o.photos.fife.usercontent.google.com|o.photos.google.com|s.IN:fQiibdzTtpGQdDd990_QaXfPVAm1G-QaIo2N2RcgRfMzSBx0tOODs6_eVZvLvIIUrG9Pcw.; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-1PLSID=o.chat.google.com|o.chromewebstore.google.com|o.drive.google.com|o.gds.google.com|o.mail.google.com|o.meet.google.com|o.photos.fife.usercontent.google.com|o.photos.google.com|s.IN:fQiibdzTtpGQdDd990_QaXfPVAm1G-QaIo2N2RcgRfMzSBx0RnZwpj2XEzByxVVQAsR2Yw.; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-3PLSID=o.chat.google.com|o.chromewebstore.google.com|o.drive.google.com|o.gds.google.com|o.mail.google.com|o.meet.google.com|o.photos.fife.usercontent.google.com|o.photos.google.com|s.IN:fQiibdzTtpGQdDd990_QaXfPVAm1G-QaIo2N2RcgRfMzSBx08rhNG4Wo6HcxpJE8oG5NAg.; DOMAIN=accounts.google.com");

	web_add_cookie("1P_JAR=2024-02-07-11; DOMAIN=accounts.google.com");

	web_add_cookie("AEC=Ae3NU9P1RIOYM51630pMStR7Ih7xbKhlZPhdtjuj1jxtOhIuq1vGnsEc288; DOMAIN=accounts.google.com");

	web_add_cookie("NID=511=jhLzroJL3hq4BLIop2hlqf7r2s8qwYvVSJwvp_utyJ9-OzJoG1A9cPSBJXZLkNIs9Vgl9Md0jZ8YRAk812uGY0H0l77J6O02Fc9oIA9wXuja1iBMljJUWM2YpSsBA5RUM3aM-3Kij32IKoFVDYiJC2ySHBmfvwPHD1aFZnyn4KGEtXk81YGl-JdTHuZWvv5CPKy4tSVDjDoJKmiV9Nc15uusn2EoZgpkgtMpT21hDHLTDQfolG7MPedlCWkGQs4mNJPHo1L7-5GqHdt6N9ToWD9YZkCPCAYF-zf_YRhstsXd9ANvKwFfxEANEkhucvbe; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PSIDTS=sidts-CjIBPVxjSvKnySnI03C4PDFzRkowDu6CneVjl4ZtWLcnCvwMVcZOO_ozs1J4pBq6sQBNshAA; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PSIDTS=sidts-CjIBPVxjSvKnySnI03C4PDFzRkowDu6CneVjl4ZtWLcnCvwMVcZOO_ozs1J4pBq6sQBNshAA; DOMAIN=accounts.google.com");

	web_add_cookie("SIDCC=ABTWhQHay3xJzumLriQ0HY5f9aE3naHNM-NfZFGdor4RCYiMJUFgZkD0ivJkCd98VJhJlXp02w; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PSIDCC=ABTWhQFcCuU35-0qx5hkHo8q2och1l52qrj1TNwiYcfQIfRTcMFJ5USOAQuFaRBGUFkOCbbBl2g; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PSIDCC=ABTWhQEz5Nd9L8XlXmO8LeNGktaQvlMYZRonNmT7S9sAWH8H8mWL4ICG_pk-hNVQs-v7EJyoWCk; DOMAIN=accounts.google.com");

	web_custom_request("ListAccounts", 
		"URL=https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		"Body= ", 
		LAST);

	lr_think_time(9);

	web_custom_request("command", 
		"URL=https://clients4.google.com/chrome-sync/command/?client=Google+Chrome&client_id=EqBJmtXuwdBaPOmd8C%2FKQg%3D%3D", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/vnd.google.octet-stream-compressible", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/octet-stream", 
		"BodyBinary=\n\\x18shilpagowda939@gmail.com\\x10c\\x18\\x02*'\\x12\\x04\\x08\\x00\\x10\\x00\\x18\\x012\\x04\\x08\\xDE\\xD8\\x122\\x13\\x08\\x81\\xF5\\x02\\x12\r \\x00\\x88\\x01\\xAF\\xC8\\xC9\\xCB\\xC4\\x9F\\xD4\\xB4\\x01@\\x00H\\x07:%z00000162-c454-d76e-0000-00005ad2013dR\\x12\n\\x02\\x08\\x05\n\\x02\\x08\t\n\\x02\\x08\n\\x10\\x01\\x18\\x00 \\x00Z\\x81\\x01\n\\x7F\\x12}Chrome WIN 121.0.6167.141 (a5856993c61543d4acbee5f848f1750607e87ba0-refs/branch-heads/6167@{#1684}) channel(stable),gzip(gfe)"
		"b'AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgwj\\x02\\x10\\x00", 
		LAST);

	web_url("www.bunnycart.com", 
		"URL=https://www.bunnycart.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_concurrent_start(NULL);

	web_url("da81c73bcc9284f25f077f97fb4ac4fe.min.css", 
		"URL=https://www.bunnycart.com/pub/static/_cache/merged/da81c73bcc9284f25f077f97fb4ac4fe.min.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://www.bunnycart.com/", 
		"Snapshot=t4.inf", 
		LAST);

	web_url("styles-l.min.css", 
		"URL=https://www.bunnycart.com/pub/static/frontend/Smartwave/porto/en_GB/css/styles-l.min.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://www.bunnycart.com/", 
		"Snapshot=t5.inf", 
		LAST);

	web_url("print.min.css", 
		"URL=https://www.bunnycart.com/pub/static/frontend/Smartwave/porto/en_GB/css/print.min.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://www.bunnycart.com/", 
		"Snapshot=t6.inf", 
		LAST);

	web_url("bootstrap.optimized.min.css", 
		"URL=https://www.bunnycart.com/pub/media/porto/web/bootstrap/css/bootstrap.optimized.min.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://www.bunnycart.com/", 
		"Snapshot=t7.inf", 
		LAST);

	web_url("animate.optimized.css", 
		"URL=https://www.bunnycart.com/pub/media/porto/web/css/animate.optimized.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://www.bunnycart.com/", 
		"Snapshot=t8.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_custom_request("v3", 
		"URL=https://a.nel.cloudflare.com/report/v3?s=08r7T6Jg4XX0C%2FrZS2QVG0QXa6PepShVWgZ%2BqKB7kPhtGpDFCvoZp8hZ77FTCeyga%2F4IQku1t5bP%2FtvwgE8V3xbrUIyk8i%2FqrXens0%2B5Toz81aMJQBgMDUM7w0PYDELFK%2FE%2F", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_concurrent_start(NULL);

	web_url("js", 
		"URL=https://www.googletagmanager.com/gtag/js?id=", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=https://www.bunnycart.com/", 
		"Snapshot=t10.inf", 
		LAST);

	web_url("js_2", 
		"URL=https://www.googletagmanager.com/gtag/js?id=AW-852445990", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=https://www.bunnycart.com/", 
		"Snapshot=t11.inf", 
		LAST);

	web_url("fbevents.js", 
		"URL=https://connect.facebook.net/en_US/fbevents.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://www.bunnycart.com/", 
		"Snapshot=t12.inf", 
		LAST);

	web_url("gtm.js", 
		"URL=https://www.googletagmanager.com/gtm.js?id=GTM-NDRWWF", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=https://www.bunnycart.com/", 
		"Snapshot=t13.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_set_sockets_option("TLS_SNI", "0");

	web_set_sockets_option("TLS_SNI", "1");

	web_url("852445990", 
		"URL=https://td.doubleclick.net/td/rul/852445990?random=1707304972179&cv=11&fst=1707304972179&fmt=3&bg=ffffff&guid=ON&async=1&gtm=45be4250za200&gcd=13l3l3l3l1&dma=0&u_w=1280&u_h=720&url=https%3A%2F%2Fwww.bunnycart.com%2F&hn=www.googleadservices.com&frm=0&tiba=Buy%20Aquatic%20Plants%20%26%20Aquarium%20Fish%20online&npa=0&pscdl=noapi&auid=1377808016.1707304972&uaa=x86&uab=64&uafvl=Not%2520A(Brand%3B99.0.0.0%7CGoogle%2520Chrome%3B121.0.6167.141%7CChromium%3B121.0.6167.141&uamb=0&uap=Windows&uapv="
		"10.0.0&uaw=0&fledge=1&data=event%3Dgtag.config", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.bunnycart.com/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_url("852445990_2", 
		"URL=https://td.doubleclick.net/td/rul/852445990?random=1707304972253&cv=11&fst=1707304972253&fmt=3&bg=ffffff&guid=ON&async=1&gtm=45be4250za200&gcd=13l3l3l3l1&dma=0&u_w=1280&u_h=720&url=https%3A%2F%2Fwww.bunnycart.com%2F&label=2_osCP3Pwe8BEKaWvZYD&hn=www.googleadservices.com&frm=0&tiba=Buy%20Aquatic%20Plants%20%26%20Aquarium%20Fish%20online&gtm_ee=1&npa=0&pscdl=noapi&auid=1377808016.1707304972&uaa=x86&uab=64&uafvl=Not%2520A"
		"(Brand%3B99.0.0.0%7CGoogle%2520Chrome%3B121.0.6167.141%7CChromium%3B121.0.6167.141&uamb=0&uap=Windows&uapv=10.0.0&uaw=0&ec_m=body%3E%3Anth-child(6)%3E%3Anth-child(6)%3E%3Anth-child(1)%3E%3Anth-child(2)%3E%3Anth-child(1)%3E%3Anth-child(2)%3E%3Anth-child(2)%3E%3Anth-child(1)%3E%3Anth-child(1)%3E%3Anth-child(1)%3E%3Anth-child(6)%3E%3Anth-child(1)%3E%3Anth-child(1)%3E%3Anth-child(2)%3E%3Anth-child(1)*P%3Atrue%3A21%3Afalse*1~body%3E%3Anth-child(6)%3E%3Anth-child(6)%3E%3Anth-child(1)%3E%3Anth-child(2)"
		"%3E%3Anth-child(1)%3E%3Anth-child(2)%3E%3Anth-child(2)%3E%3Anth-child(1)%3E%3Anth-child(1)%3E%3Anth-child(1)%3E%3Anth-child(12)%3E%3Anth-child(1)%3E%3Anth-child(1)%3E%3Anth-child(2)%3E%3Anth-child(1)*P%3Atrue%3A21%3Afalse*1&ec_sel=body%3E%3Anth-child(6)%3E%3Anth-child(6)%3E%3Anth-child(1)%3E%3Anth-child(2)%3E%3Anth-child(1)%3E%3Anth-child(2)%3E%3Anth-child(2)%3E%3Anth-child(1)%3E%3Anth-child(1)%3E%3Anth-child(1)%3E%3Anth-child(6)%3E%3Anth-child(1)%3E%3Anth-child(1)%3E%3Anth-child(2)%3E%3Anth-child"
		"(1)&ec_meta=P%3Atrue%3A21%3Afalse&ec_lat=6&ec_s=1&ec_mode=a&fledge=1&capi=1&data=event%3Dconversion&em=tv.1~em.eWi5Zbg0K1E-XToG4ZZx60KoVOtHc9la6feKDdkWXzs", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.bunnycart.com/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	web_concurrent_start(NULL);

	web_url("tr", 
		"URL=https://www.facebook.com/tr/?id=465845273623930&ev=PageView&dl=https%3A%2F%2Fwww.bunnycart.com%2F&rl=&if=false&ts=1707304972745&sw=1280&sh=720&v=2.9.145&r=stable&ec=0&o=4126&fbp=fb.1.1707304972725.1453159239&cs_est=true&ler=empty&cdl=API_unavailable&it=1707304972129&coo=false&exp=e1&rqm=GET", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=https://www.bunnycart.com/", 
		"Snapshot=t16.inf", 
		LAST);

	web_url("trigger", 
		"URL=https://www.facebook.com/privacy_sandbox/pixel/register/trigger/?id=465845273623930&ev=PageView&dl=https%3A%2F%2Fwww.bunnycart.com%2F&rl=&if=false&ts=1707304972745&sw=1280&sh=720&v=2.9.145&r=stable&ec=0&o=4126&fbp=fb.1.1707304972725.1453159239&cs_est=true&ler=empty&cdl=API_unavailable&it=1707304972129&coo=false&exp=e1&rqm=FGET", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://www.bunnycart.com/", 
		"Snapshot=t17.inf", 
		LAST);

	web_concurrent_end(NULL);

	return 0;
}