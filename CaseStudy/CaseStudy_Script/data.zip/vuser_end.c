vuser_end()
{

	/* logout */

	return 0;
}